import { useEffect, useState, useCallback } from 'react';

export const ClickRipple = () => {
  const [ripples, setRipples] = useState([]);
  const [isTouch, setIsTouch] = useState(false);

  useEffect(() => {
    setIsTouch('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  const handleClick = useCallback((e) => {
    // 仅空白区域点击
    const tag = e.target.tagName.toLowerCase();
    const isInteractive = ['button', 'a', 'input', 'select', 'textarea', 'label'].includes(tag)
      || e.target.closest('button, a, [role="button"], input, select, textarea, label')
      || e.target.closest('.btn-interactive');
    if (isInteractive) return;

    const id = Date.now() + Math.random();
    setRipples((prev) => [...prev.slice(-5), { id, x: e.clientX, y: e.clientY }]);
    setTimeout(() => {
      setRipples((prev) => prev.filter((r) => r.id !== id));
    }, 500);
  }, []);

  useEffect(() => {
    if (isTouch) return;
    window.addEventListener('click', handleClick);
    return () => window.removeEventListener('click', handleClick);
  }, [handleClick, isTouch]);

  if (isTouch) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9997]" style={{ overflow: 'hidden' }}>
      {ripples.map((r) => (
        <div
          key={r.id}
          className="absolute rounded-full animate-click-ripple"
          style={{
            left: r.x,
            top: r.y,
            width: 0,
            height: 0,
            border: '2px solid #818cf8',
            transform: 'translate(-50%, -50%)',
          }}
        />
      ))}
      <style>{`
        @keyframes click-ripple {
          0% { width: 0; height: 0; opacity: 0.4; border-width: 3px; }
          100% { width: 80px; height: 80px; opacity: 0; border-width: 0.5px; }
        }
        .animate-click-ripple { animation: click-ripple 0.5s ease-out forwards; }
      `}</style>
    </div>
  );
};