import { useRef, useEffect } from 'react';
import { useApp } from '../context/AppContext';

/**
 * KnowledgeTagCloud - 轻量化动态知识标签云
 * 标签围绕核心主题词缓慢旋转浮动
 */
export function KnowledgeTagCloud({ tags, centerText = '知识基因' }) {
  const { theme } = useApp();
  const containerRef = useRef(null);
  const animRef = useRef(null);
  const tagsRef = useRef([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container || tags.length === 0) return;

    const centerX = 60;
    const centerY = 55;
    const radiusX = 50;
    const radiusY = 38;
    const count = tags.length;

    const tagElements = container.querySelectorAll('.tag-cloud-item');
    const tagData = Array.from({ length: count }, (_, i) => ({
      el: tagElements[i],
      angle: (i / count) * Math.PI * 2,
      speed: 0.12 + Math.random() * 0.2,
      radiusOffset: 0.85 + Math.random() * 0.3,
    }));
    tagsRef.current = tagData;

    let frame;
    const animate = (time) => {
      const t = time * 0.001;
      tagData.forEach((tag, i) => {
        tag.angle += tag.speed * 0.01;
        const r = radiusX * tag.radiusOffset;
        const ry = radiusY * tag.radiusOffset;
        const x = centerX + Math.cos(tag.angle) * r;
        const y = centerY + Math.sin(tag.angle) * ry * 3;
        const opacity = 0.4 + (Math.sin(tag.angle * 2 + t) + 1) * 0.25;
        const scale = 0.7 + (Math.cos(tag.angle + t) + 1) * 0.2;

        tag.el.style.left = `${x}%`;
        tag.el.style.top = `${y}%`;
        tag.el.style.opacity = opacity;
        tag.el.style.transform = `translate(-50%, -50%) scale(${scale})`;
      });
      frame = requestAnimationFrame(animate);
    };
    frame = requestAnimationFrame(animate);

    return () => { if (frame) cancelAnimationFrame(frame); };
  }, [tags]);

  return (
    <div
      ref={containerRef}
      className="relative w-full h-28 overflow-hidden rounded-xl select-none"
      style={{
        background: theme === 'dark'
          ? 'linear-gradient(135deg, rgba(30,27,75,0.6), rgba(15,23,42,0.6))'
          : 'linear-gradient(135deg, rgba(238,242,255,0.7), rgba(248,250,252,0.7))',
      }}
    >
      {/* 核心主题词 */}
      <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none">
        <span className={`text-xs font-bold ${theme === 'dark' ? 'text-indigo-300' : 'text-indigo-500'}`}>
          {centerText}
        </span>
      </div>

      {/* 浮动标签 */}
      {tags.map((tag, i) => (
        <span
          key={`${tag}-${i}`}
          className={`tag-cloud-item absolute px-2 py-0.5 rounded-full text-[10px] font-medium whitespace-nowrap transition-colors duration-200 hover:scale-125 hover:z-20 cursor-default ${
            theme === 'dark'
              ? 'bg-gray-800/80 text-gray-300 hover:bg-indigo-900/60 hover:text-indigo-300'
              : 'bg-white/80 text-gray-600 hover:bg-indigo-50 hover:text-indigo-600'
          }`}
          style={{
            boxShadow: '0 1px 3px rgba(0,0,0,0.06)',
          }}
        >
          {tag}
        </span>
      ))}
    </div>
  );
}

export default KnowledgeTagCloud;