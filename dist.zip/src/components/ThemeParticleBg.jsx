import { useRef, useEffect } from 'react';

/**
 * ThemeParticleBg - 主题粒子背景装饰
 * 书本、DNA链等图标缓慢无规则浮动，弱装饰元素
 */
const ICONS = ['📖', '📝', '🧬', '🔬', '📊', '💡', '🎓', '📚', '⚛️', '🔗'];

export function ThemeParticleBg({ particleCount = 12 }) {
  const containerRef = useRef(null);
  const animRef = useRef(null);
  const particlesRef = useRef([]);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const rect = container.getBoundingClientRect();
    const w = rect.width;
    const h = rect.height;

    const particles = Array.from({ length: particleCount }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      vx: (Math.random() - 0.5) * 0.3,
      vy: (Math.random() - 0.5) * 0.3,
      icon: ICONS[Math.floor(Math.random() * ICONS.length)],
      size: 10 + Math.random() * 14,
      opacity: 0.06 + Math.random() * 0.08,
      rotation: Math.random() * 360,
      rotSpeed: (Math.random() - 0.5) * 0.3,
    }));
    particlesRef.current = particles;

    const frame = () => {
      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;
        p.rotation += p.rotSpeed;
        if (p.x < -20) p.x = w + 20;
        if (p.x > w + 20) p.x = -20;
        if (p.y < -20) p.y = h + 20;
        if (p.y > h + 20) p.y = -20;
      });
      animRef.current = requestAnimationFrame(frame);
    };
    animRef.current = requestAnimationFrame(frame);

    return () => { if (animRef.current) cancelAnimationFrame(animRef.current); };
  }, [particleCount]);

  return (
    <div ref={containerRef} className="absolute inset-0 overflow-hidden pointer-events-none">
      {particlesRef.current.map((p, i) => (
        <span
          key={i}
          className="absolute select-none"
          style={{
            left: `${p.x}px`,
            top: `${p.y}px`,
            fontSize: `${p.size}px`,
            opacity: p.opacity,
            transform: `rotate(${p.rotation}deg)`,
          }}
        >
          {p.icon}
        </span>
      ))}
    </div>
  );
}

export default ThemeParticleBg;