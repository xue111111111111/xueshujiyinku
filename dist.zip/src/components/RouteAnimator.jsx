import { useRef, useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';

/**
 * RouteAnimator - 全局路由过渡动画容器
 *
 * 使用 key 触发 CSSTransition 实现页面进出场动画：
 * - 进入: opacity 0→1 + translateY(12px)→0
 * - 离开: opacity 1→0 + translateY(0)→-12px
 */
export function RouteAnimator({ activeTab, children }) {
  const { theme } = useApp();
  const [displayChildren, setDisplayChildren] = useState(children);
  const [transitionState, setTransitionState] = useState('entered');
  const prevTabRef = useRef(activeTab);

  useEffect(() => {
    if (prevTabRef.current !== activeTab) {
      // Exit current
      setTransitionState('exiting');

      const exitTimer = setTimeout(() => {
        // Update children after exit animation
        setDisplayChildren(children);
        prevTabRef.current = activeTab;
        setTransitionState('entering');

        // Enter animation
        requestAnimationFrame(() => {
          requestAnimationFrame(() => {
            setTransitionState('entered');
          });
        });
      }, 280);

      return () => clearTimeout(exitTimer);
    } else {
      setDisplayChildren(children);
    }
  }, [activeTab, children]);

  const getTransitionStyle = () => {
    const base = {
      transition: 'all 0.35s cubic-bezier(0.16, 1, 0.3, 1)',
      willChange: 'transform, opacity',
    };

    switch (transitionState) {
      case 'entering':
        return { ...base, opacity: 0, transform: 'translateY(12px)' };
      case 'exiting':
        return { ...base, opacity: 0, transform: 'translateY(-12px)' };
      case 'entered':
        return { ...base, opacity: 1, transform: 'translateY(0)' };
      default:
        return base;
    }
  };

  return (
    <div
      key={`route-${activeTab}`}
      style={getTransitionStyle()}
      className="w-full"
    >
      {displayChildren}
    </div>
  );
}

export default RouteAnimator;