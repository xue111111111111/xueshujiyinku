import { useRef, useEffect, useState, useCallback } from 'react';
import { getAssets, getRelayProjects, getGeneChain } from '../utils/storage';
import { useApp } from '../context/AppContext';
import { X, GitBranch, BookOpen, GraduationCap, Zap } from 'lucide-react';

const NODE_RADIUS = 10;
const CONNECTION_DIST = 160;
const DRIFT_SPEED = 0.15;

export function GeneChain() {
  const { theme } = useApp();
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const nodesRef = useRef([]);
  const edgesRef = useRef([]);
  const animRef = useRef(null);
  const mouseRef = useRef({ x: -100, y: -100, hoverNode: null });
  const [selectedNode, setSelectedNode] = useState(null);
  const [tooltipNode, setTooltipNode] = useState(null);
  const [tooltipPos, setTooltipPos] = useState({ x: 0, y: 0 });

  // 构建图谱节点和连线
  useEffect(() => {
    const assets = getAssets();
    const relayProjects = getRelayProjects();
    const geneChain = getGeneChain();

    const nodes = [];
    const edges = [];

    // 资产节点
    const assetNodes = assets.slice(0, 25).map((a, i) => ({
      id: `asset-${a.id}`,
      type: 'asset',
      label: a.title.length > 8 ? a.title.slice(0, 8) + '…' : a.title,
      fullTitle: a.title,
      course: a.course || '',
      typeName: a.type || '',
      authorId: a.authorId,
      x: 100 + Math.random() * 600,
      y: 100 + Math.random() * 400,
      vx: (Math.random() - 0.5) * DRIFT_SPEED,
      vy: (Math.random() - 0.5) * DRIFT_SPEED,
      color: '#6366f1',
      radius: 8 + Math.random() * 4
    }));

    // 接力项目节点
    const relayNodes = relayProjects.slice(0, 15).map((r, i) => ({
      id: `relay-${r.id}`,
      type: 'relay',
      label: r.title.length > 8 ? r.title.slice(0, 8) + '…' : r.title,
      fullTitle: r.title,
      status: r.status,
      difficulty: r.difficulty,
      x: 100 + Math.random() * 600,
      y: 100 + Math.random() * 400,
      vx: (Math.random() - 0.5) * DRIFT_SPEED,
      vy: (Math.random() - 0.5) * DRIFT_SPEED,
      color: '#8b5cf6',
      radius: 9 + Math.random() * 4
    }));

    nodes.push(...assetNodes, ...relayNodes);

    // 基于基因链数据构建连线
    geneChain.forEach(link => {
      const srcNode = nodes.find(n => 
        n.id === `asset-${link.fromAssetId}` || n.id === `relay-${link.fromProjectId}`
      );
      const tgtNode = nodes.find(n =>
        n.id === `asset-${link.toAssetId}` || n.id === `relay-${link.toProjectId}`
      );
      if (srcNode && tgtNode) {
        edges.push({ from: srcNode.id, to: tgtNode.id, relation: link.relation });
      }
    });

    // 自动连接同类型的相邻节点
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const dx = nodes[i].x - nodes[j].x;
        const dy = nodes[i].y - nodes[j].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < CONNECTION_DIST && nodes[i].type === nodes[j].type) {
          if (!edges.some(e =>
            (e.from === nodes[i].id && e.to === nodes[j].id) ||
            (e.from === nodes[j].id && e.to === nodes[i].id)
          )) {
            edges.push({ from: nodes[i].id, to: nodes[j].id, relation: '相关' });
          }
        }
      }
    }

    nodesRef.current = nodes;
    edgesRef.current = edges;
  }, []);

  // Canvas 渲染循环
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    let w, h;
    const dpr = window.devicePixelRatio || 1;

    const resize = () => {
      const rect = container.getBoundingClientRect();
      w = rect.width;
      h = rect.height;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = `${w}px`;
      canvas.style.height = `${h}px`;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };

    resize();
    const resizeObserver = new ResizeObserver(resize);
    resizeObserver.observe(container);

    const nodes = nodesRef.current;
    const edges = edgesRef.current;

    const animate = () => {
      ctx.clearRect(0, 0, w, h);

      // 背景网格
      ctx.strokeStyle = theme === 'dark' ? 'rgba(75,85,99,0.08)' : 'rgba(0,0,0,0.04)';
      ctx.lineWidth = 0.5;
      const gridSize = 40;
      for (let x = gridSize; x < w; x += gridSize) {
        ctx.beginPath();
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
        ctx.stroke();
      }
      for (let y = gridSize; y < h; y += gridSize) {
        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
      }

      // 力导向更新节点位置
      nodes.forEach((n, i) => {
        // 漂移
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 30 || n.x > w - 30) n.vx *= -1;
        if (n.y < 30 || n.y > h - 30) n.vy *= -1;

        // 排斥力
        for (let j = i + 1; j < nodes.length; j++) {
          const dx = n.x - nodes[j].x;
          const dy = n.y - nodes[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          if (dist < 100) {
            const force = 0.5 / (dist * dist);
            const fx = (dx / dist) * force;
            const fy = (dy / dist) * force;
            n.x += fx;
            n.y += fy;
            nodes[j].x -= fx;
            nodes[j].y -= fy;
          }
        }
      });

      // 绘制连线
      edges.forEach(edge => {
        const from = nodes.find(n => n.id === edge.from);
        const to = nodes.find(n => n.id === edge.to);
        if (!from || !to) return;

        const alpha = theme === 'dark' ? 0.12 : 0.1;
        ctx.beginPath();
        ctx.moveTo(from.x, from.y);
        ctx.lineTo(to.x, to.y);
        ctx.strokeStyle = `rgba(99,102,241,${alpha})`;
        ctx.lineWidth = 0.8;
        ctx.stroke();
      });

      // 找出hover的节点
      let hovered = null;
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;

      // 绘制节点
      nodes.forEach(n => {
        const isHovered = Math.hypot(mx - n.x, my - n.y) < n.radius + 4;

        // 外发光
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius + 6, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(99,102,241,${isHovered ? 0.18 : 0.06})`;
        ctx.fill();

        // 节点圆
        ctx.beginPath();
        ctx.arc(n.x, n.y, isHovered ? n.radius + 2 : n.radius, 0, Math.PI * 2);
        ctx.fillStyle = n.type === 'relay' ? '#8b5cf6' : '#6366f1';
        ctx.fill();

        // 内圈
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius * 0.4, 0, Math.PI * 2);
        ctx.fillStyle = 'rgba(255,255,255,0.5)';
        ctx.fill();

        // 标签
        if (isHovered) {
          ctx.font = '11px sans-serif';
          ctx.fillStyle = theme === 'dark' ? '#e5e7eb' : '#374151';
          ctx.textAlign = 'center';
          ctx.fillText(n.label, n.x, n.y - n.radius - 10);
          hovered = n;
        }
      });

      // 记录hover状态
      mouseRef.current.hoverNode = hovered;

      animRef.current = requestAnimationFrame(animate);
    };

    animRef.current = requestAnimationFrame(animate);

    return () => {
      resizeObserver.disconnect();
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [theme]);

  // 鼠标交互
  const handleMouseMove = useCallback((e) => {
    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;
    mouseRef.current.x = e.clientX - rect.left;
    mouseRef.current.y = e.clientY - rect.top;

    const hovered = mouseRef.current.hoverNode;
    if (hovered && canvasRef.current) {
      setTooltipNode(hovered);
      setTooltipPos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
    } else {
      setTooltipNode(null);
    }
  }, []);

  const handleMouseLeave = useCallback(() => {
    mouseRef.current.x = -100;
    mouseRef.current.y = -100;
    setTooltipNode(null);
  }, []);

  const handleClick = useCallback(() => {
    const hovered = mouseRef.current.hoverNode;
    if (hovered) {
      setSelectedNode(hovered);
    }
  }, []);

  const getTypeIcon = (type) => {
    switch (type) {
      case 'relay': return <GitBranch className="w-4 h-4" />;
      case 'asset': return <BookOpen className="w-4 h-4" />;
      default: return <Zap className="w-4 h-4" />;
    }
  };

  const getTypeLabel = (type) => {
    switch (type) {
      case 'relay': return '接力项目';
      case 'asset': return '学术产出';
      default: return '知识节点';
    }
  };

  return (
    <div className="relative" style={{ height: 500 }}>
      {/* 标题区 */}
      <div className={`flex items-center justify-between mb-4 px-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center">
            <GitBranch className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="font-bold text-lg">学术基因链</h3>
            <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              知识图谱可视化 · 节点可拖拽探索
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-4 text-xs">
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded-full bg-indigo-500" />
            <span className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>学术产出</span>
          </span>
          <span className="flex items-center space-x-1">
            <span className="w-3 h-3 rounded-full bg-purple-500" />
            <span className={theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}>接力项目</span>
          </span>
        </div>
      </div>

      {/* Canvas区域 */}
      <div
        ref={containerRef}
        className="relative rounded-xl overflow-hidden cursor-crosshair"
        style={{
          height: 420,
          background: theme === 'dark'
            ? 'linear-gradient(135deg, #0f172a 0%, #1e1b4b 50%, #0f172a 100%)'
            : 'linear-gradient(135deg, #f8fafc 0%, #eef2ff 50%, #f8fafc 100%)'
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        onClick={handleClick}
      >
        <canvas ref={canvasRef} className="w-full h-full" />

        {/* Tooltip */}
        {tooltipNode && (
          <div
            className="absolute pointer-events-none z-20 tooltip-enter"
            style={{
              left: tooltipPos.x + 16,
              top: tooltipPos.y - 40,
              maxWidth: 200
            }}
          >
            <div className={`px-3 py-2 rounded-lg shadow-lg text-xs ${
              theme === 'dark' ? 'bg-gray-800 text-white border border-gray-700' : 'bg-white text-gray-800 border border-gray-200'
            }`}>
              <p className="font-medium">{tooltipNode.fullTitle}</p>
              <p className={`mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {getTypeLabel(tooltipNode.type)}
                {tooltipNode.course && ` · ${tooltipNode.course}`}
                {tooltipNode.status && ` · ${tooltipNode.status}`}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* 节点详情弹窗 */}
      {selectedNode && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setSelectedNode(null)}>
          <div
            className={`spring-enter w-full max-w-md rounded-xl shadow-xl p-6 ${
              theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'
            }`}
            onClick={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                  selectedNode.type === 'relay' ? 'bg-purple-100' : 'bg-indigo-100'
                }`}>
                  {getTypeIcon(selectedNode.type)}
                </div>
                <div>
                  <h3 className="font-bold text-lg">{selectedNode.fullTitle}</h3>
                  <p className="text-xs text-gray-500">{getTypeLabel(selectedNode.type)}</p>
                </div>
              </div>
              <button onClick={() => setSelectedNode(null)} className="p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-3 text-sm">
              {selectedNode.course && (
                <div className="flex justify-between">
                  <span className="text-gray-500">所属课程</span>
                  <span>{selectedNode.course}</span>
                </div>
              )}
              {selectedNode.typeName && (
                <div className="flex justify-between">
                  <span className="text-gray-500">资料类型</span>
                  <span>{selectedNode.typeName}</span>
                </div>
              )}
              {selectedNode.status && (
                <div className="flex justify-between">
                  <span className="text-gray-500">项目状态</span>
                  <span className={`px-2 py-0.5 rounded-full text-xs ${
                    selectedNode.status === 'completed' ? 'bg-green-100 text-green-700' :
                    selectedNode.status === 'recruiting' ? 'bg-blue-100 text-blue-700' :
                    'bg-yellow-100 text-yellow-700'
                  }`}>
                    {selectedNode.status === 'completed' ? '已传承' :
                     selectedNode.status === 'recruiting' ? '待接力' : '接力中'}
                  </span>
                </div>
              )}
              {selectedNode.difficulty && (
                <div className="flex justify-between">
                  <span className="text-gray-500">难度等级</span>
                  <span>{selectedNode.difficulty}</span>
                </div>
              )}
            </div>

            <div className="mt-4 pt-4 border-t border-gray-200 dark:border-gray-700">
              <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                关联链路：{edgesRef.current.filter(e => e.from === selectedNode.id || e.to === selectedNode.id).length} 条知识连线
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default GeneChain;