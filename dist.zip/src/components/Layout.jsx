import { useState, useEffect, useRef, useCallback } from 'react';
import {
  BookOpen,
  GraduationCap,
  Award,
  Search,
  ShoppingCart,
  BarChart3,
  Settings,
  Sun,
  Moon,
  Menu,
  X,
  ChevronDown,
  GitBranch,
  Users,
  User,
  FileCheck,
  Coins,
  Shield,
  LogOut,
  RefreshCw,
  FileEdit,
  Sparkles,
  ClipboardCheck,
  ClipboardList,
  UserCheck,
  BookMarked,
  MoreHorizontal,
  ArrowRight
} from 'lucide-react';
import { useApp } from '../context/AppContext';

// ============================================================
//  导航项分组定义（核心/次要/用户操作）
// ============================================================

// 学生端 — 核心高频入口优先
const studentNavGroups = {
  core: [
    { id: 'assets', label: '学习产出', icon: BookOpen },
    { id: 'relay', label: '跨期接力', icon: GitBranch },
    { id: 'genechain', label: '基因链', icon: Sparkles },
    { id: 'shop', label: '积分商城', icon: ShoppingCart },
    { id: 'mergerequests', label: '我的申请', icon: ClipboardList },
    { id: 'badges', label: '成就徽章', icon: Award },
    { id: 'search', label: '资料检索', icon: Search },
  ],
  secondary: [],
  alwaysOverflow: [
    { id: 'stats', label: '统计看板', icon: BarChart3 },
    { id: 'profile', label: '个人主页', icon: User },
  ]
};

// 老师端
const teacherNavGroups = {
  core: [
    { id: 'mycourses', label: '我的课程', icon: BookMarked },
    { id: 'homework', label: '作业管理', icon: FileEdit },
    { id: 'genechain', label: '基因链', icon: Sparkles },
    { id: 'badges', label: '成就徽章', icon: Award },
  ],
  secondary: [
    { id: 'cases', label: '教学案例', icon: Award },
    { id: 'approval', label: '接力审批', icon: ClipboardCheck },
  ],
  alwaysOverflow: [
    { id: 'stats', label: '统计看板', icon: BarChart3 },
  ]
};

// 管理员端
const adminNavGroups = {
  core: [
    { id: 'usermanage', label: '用户管理', icon: Users },
    { id: 'contentaudit', label: '内容审核', icon: FileCheck },
    { id: 'genechain', label: '基因链', icon: Sparkles },
  ],
  secondary: [
    { id: 'pointconfig', label: '积分配置', icon: Coins },
    { id: 'system', label: '系统设置', icon: Shield },
  ],
  alwaysOverflow: [
    { id: 'stats', label: '全局统计看板', icon: BarChart3 },
  ]
};

// ============================================================
//  useOverflowMenu — ResizeObserver 溢出检测 hook
// ============================================================
function useOverflowMenu(allItems, containerRef, gapPx = 4, reservedWidth = 340) {
  const [visibleItems, setVisibleItems] = useState(allItems);
  const [overflowItems, setOverflowItems] = useState([]);

  const recalc = useCallback(() => {
    const container = containerRef.current;
    if (!container) return;

    const available = container.offsetWidth - reservedWidth;
    if (available <= 0) {
      setVisibleItems([]);
      setOverflowItems(allItems);
      return;
    }

    // 测量每个项的估算宽度
    const itemWidths = allItems.map(() => 100); // 估算每个导航项 ~100px（icon+label+padding）
    let used = 0;
    const vis = [];
    const over = [];

    for (let i = 0; i < allItems.length; i++) {
      const w = itemWidths[i] + (vis.length > 0 ? gapPx : 0);
      if (used + w <= available - 44) { // 44px more按钮宽度
        vis.push(allItems[i]);
        used += w;
      } else {
        over.push(allItems[i]);
      }
    }

    setVisibleItems(vis);
    setOverflowItems(over);
  }, [allItems, containerRef, gapPx, reservedWidth]);

  useEffect(() => {
    recalc();
    const ro = new ResizeObserver(recalc);
    const container = containerRef.current;
    if (container) ro.observe(container);
    return () => ro.disconnect();
  }, [recalc, containerRef]);

  return { visibleItems, overflowItems };
}

// ============================================================
//  NavItem 组件
// ============================================================
function NavItem({ item, isActive, onTabChange, theme, iconOnly }) {
  const Icon = item.icon;
  return (
    <button
      onClick={() => onTabChange(item.id)}
      title={iconOnly ? item.label : undefined}
      className={`btn-interactive flex items-center rounded-lg transition-all duration-200 whitespace-nowrap ${
        iconOnly ? 'space-x-0 px-2 py-1.5' : 'space-x-1.5 px-2.5 py-1.5'
      } ${
        isActive
          ? `${theme === 'dark' ? 'bg-primary-600 text-white shadow-md' : 'bg-primary-500 text-white shadow-md'}`
          : theme === 'dark'
          ? 'text-gray-300 hover:bg-gray-800 hover:text-white'
          : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
      }`}
    >
      <Icon className={iconOnly ? 'w-4.5 h-4.5' : 'w-4 h-4'} />
      {!iconOnly && <span className="text-sm font-medium">{item.label}</span>}
    </button>
  );
}

// ============================================================
//  用户切换角色弹窗
// ============================================================
function RoleSwitchModal({ isOpen, onClose, currentUser, theme, onRoleSwitch }) {
  if (!isOpen) return null;
  const roleOptions = [
    { role: 'student', label: '学生端', description: '学习产出、跨期接力、积分商城' },
    { role: 'teacher', label: '老师端', description: '课程管理、作业审批、教学案例' },
    { role: 'admin', label: '管理员端', description: '用户管理、内容审核、系统设置' }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className={`spring-enter w-full max-w-md rounded-xl shadow-xl ${theme === 'dark' ? 'bg-gray-800' : 'bg-white'}`}>
        <div className={`px-6 py-4 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
          <h3 className={`text-lg font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            切换角色
          </h3>
          <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            选择您要切换到的角色
          </p>
        </div>
        <div className="p-6 space-y-3">
          {roleOptions.map((option) => (
            <button
              key={option.role}
              onClick={() => onRoleSwitch(option.role)}
              className={`w-full p-4 rounded-lg border-2 text-left transition-all ${
                currentUser?.role === option.role
                  ? theme === 'dark'
                    ? 'border-primary-500 bg-primary-500/20'
                    : 'border-primary-500 bg-primary-50'
                  : theme === 'dark'
                  ? 'border-gray-700 hover:border-gray-600'
                  : 'border-gray-200 hover:border-gray-300'
              }`}
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className={`font-semibold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
                    {option.label}
                    {currentUser?.role === option.role && (
                      <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${theme === 'dark' ? 'bg-primary-500' : 'bg-primary-100 text-primary-700'}`}>
                        当前
                      </span>
                    )}
                  </p>
                  <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>{option.description}</p>
                </div>
                {currentUser?.role === option.role && (
                  <UserCheck className={`w-5 h-5 ${theme === 'dark' ? 'text-primary-400' : 'text-primary-500'}`} />
                )}
              </div>
            </button>
          ))}
        </div>
        <div className={`px-6 py-4 border-t ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
          <button
            onClick={onClose}
            className={`w-full py-2.5 rounded-lg ${theme === 'dark' ? 'bg-gray-700 hover:bg-gray-600' : 'bg-gray-100 hover:bg-gray-200'}`}
          >
            取消
          </button>
        </div>
      </div>
    </div>
  );
}

// ============================================================
//  Layout 主组件
// ============================================================
export const Layout = ({ children, activeTab, onTabChange }) => {
  const { currentUser, theme, onToggleTheme, onRoleSwitch, onLogout } = useApp();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [overflowMenuOpen, setOverflowMenuOpen] = useState(false);
  const [roleModalOpen, setRoleModalOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const userMenuRef = useRef(null);
  const overflowRef = useRef(null);
  const navContainerRef = useRef(null);

  // 获取当前角色导航分组
  const getNavGroups = () => {
    switch (currentUser?.role) {
      case 'teacher': return teacherNavGroups;
      case 'admin': return adminNavGroups;
      default: return studentNavGroups;
    }
  };

  const navGroups = getNavGroups();
  const allNavItems = [...navGroups.core, ...navGroups.secondary];
  const alwaysOverflowItems = navGroups.alwaysOverflow || [];

  // 路由切换时自动关闭溢出菜单
  useEffect(() => { setOverflowMenuOpen(false); }, [activeTab]);

  // 溢出检测
  const { visibleItems, overflowItems } = useOverflowMenu(
    allNavItems,
    navContainerRef,
    4,
    360
  );

  // 合并溢出项：自动检测溢出 + 始终在更多菜单的项
  const mergedOverflowItems = [
    ...overflowItems,
    ...alwaysOverflowItems.filter(ai => !overflowItems.some(oi => oi.id === ai.id))
  ];

  // 导航栏滚动监听
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // 点击外部关闭菜单
  useEffect(() => {
    if (!userMenuOpen && !overflowMenuOpen) return;
    const handleClick = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setUserMenuOpen(false);
      }
      if (overflowRef.current && !overflowRef.current.contains(e.target)) {
        setOverflowMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [userMenuOpen, overflowMenuOpen]);

  const handleRoleSwitch = (role) => {
    onRoleSwitch(role);
    setRoleModalOpen(false);
    setUserMenuOpen(false);
    onTabChange('assets');
  };

  const handleLogout = () => {
    onLogout();
    setUserMenuOpen(false);
    onTabChange('assets');
  };

  const getRoleLabel = (role) => {
    switch (role) {
      case 'student': return '学生';
      case 'teacher': return '老师';
      case 'admin': return '管理员';
      default: return '未知';
    }
  };

  return (
    <div className={`min-h-screen transition-colors duration-300 relative z-10 ${theme === 'dark' ? 'bg-gray-900/85 text-white' : 'bg-gray-50/85 text-gray-900'}`}>
      {/* ================================================================ */}
      {/*  Header — 固定顶部导航栏                                         */}
      {/* ================================================================ */}
      <header className={`navbar-scroll sticky top-0 z-50 transition-all duration-300 ${isScrolled ? 'scrolled glass-effect-strong shadow-layer-2' : 'glass-effect'} ${theme === 'dark' ? 'border-gray-700/30' : 'border-gray-200/30'}`} style={{ borderWidth: '1px' }}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center h-14" ref={navContainerRef}>
            {/* ---- Logo (始终可见) ---- */}
            <div className="flex items-center space-x-2 shrink-0">
              <div className={`w-9 h-9 rounded-lg flex items-center justify-center transition-transform hover:scale-105 ${theme === 'dark' ? 'bg-primary-600' : 'bg-primary-500'}`}>
                <Sparkles className={`w-5 h-5 text-white title-deco-icon ${theme === 'dark' ? 'title-deco-dark' : ''}`} />
              </div>
              <h1 className={`hidden sm:block text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>学术基因库</h1>
            </div>

            {/* ---- 桌面端导航: 可见项 + 溢出菜单 ---- */}
            <nav className="hidden md:flex items-center space-x-1 ml-4" style={{ flex: '1 1 auto', minWidth: 0 }}>
              {visibleItems.map((item) => (
                <NavItem
                  key={item.id}
                  item={item}
                  isActive={activeTab === item.id}
                  onTabChange={onTabChange}
                  theme={theme}
                  iconOnly={false}
                />
              ))}
              {/* 溢出菜单按钮 */}
              {mergedOverflowItems.length > 0 && (
                <div className="relative" ref={overflowRef}>
                  <button
                    onClick={() => setOverflowMenuOpen(!overflowMenuOpen)}
                    className={`btn-interactive flex items-center space-x-1 px-2.5 py-1.5 rounded-lg transition-all duration-200 ${
                      mergedOverflowItems.some(i => i.id === activeTab)
                        ? `${theme === 'dark' ? 'bg-primary-600/60 text-white' : 'bg-primary-100 text-primary-700'}`
                        : theme === 'dark'
                        ? 'text-gray-300 hover:bg-gray-800 hover:text-white'
                        : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                    }`}
                  >
                    <MoreHorizontal className="w-4 h-4" />
                    <span className="text-sm font-medium">更多</span>
                  </button>
                  {overflowMenuOpen && (
                    <div className={`spring-enter absolute left-0 top-full mt-1 w-44 rounded-xl shadow-layer-3 py-2 z-[100] overflow-hidden glass-effect-strong ${
                      theme === 'dark' ? 'border-gray-700/50' : 'border-gray-200/50'
                    }`}>
                      {mergedOverflowItems.map((item) => {
                        const Icon = item.icon;
                        const isActive = activeTab === item.id;
                        return (
                          <button
                            key={item.id}
                            onClick={(e) => { e.stopPropagation(); onTabChange(item.id); setOverflowMenuOpen(false); }}
                            className={`w-full flex items-center space-x-2 px-4 py-2.5 text-left text-sm transition-colors ${
                              isActive
                                ? theme === 'dark' ? 'bg-primary-600/40 text-primary-200' : 'bg-primary-50 text-primary-700'
                                : theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'
                            }`}
                          >
                            <Icon className="w-4 h-4 shrink-0" />
                            <span className="truncate">{item.label}</span>
                          </button>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}
            </nav>

            {/* ---- 用户操作区（永久固定右侧） ---- */}
            <div className="flex items-center space-x-2 shrink-0 ml-auto pl-2">
              {/* 积分 — 学生端显示 */}
              {currentUser?.role === 'student' && (
                <div className={`hidden sm:flex items-center space-x-1.5 px-2.5 py-1.5 rounded-lg text-sm ${theme === 'dark' ? 'bg-yellow-600/20' : 'bg-yellow-50'}`}>
                  <span className="text-yellow-500 text-xs">🏆</span>
                  <span className={`font-semibold ${theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600'}`}>
                    {currentUser?.points || 0}
                  </span>
                  <span className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>积分</span>
                </div>
              )}

              {/* 主题切换 */}
              <button
                onClick={onToggleTheme}
                className={`p-2 rounded-lg transition-colors ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-100'}`}
                title={theme === 'dark' ? '切换到浅色模式' : '切换到深色模式'}
              >
                {theme === 'dark' ? <Sun className="w-4.5 h-4.5" /> : <Moon className="w-4.5 h-4.5" />}
              </button>

              {/* 用户菜单（永久固定） */}
              <div className="relative" ref={userMenuRef}>
                <button
                  onClick={() => setUserMenuOpen(!userMenuOpen)}
                  className={`btn-interactive flex items-center space-x-1.5 px-2 py-1.5 rounded-lg ${theme === 'dark' ? 'hover:bg-gray-800' : 'hover:bg-gray-100'}`}
                  title={currentUser?.name}
                >
                  <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 ${theme === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-600'}`}>
                    {currentUser?.name?.charAt(0) || '?'}
                  </div>
                  <span className={`hidden sm:inline text-sm font-medium truncate ${theme === 'dark' ? 'text-gray-300' : 'text-gray-700'}`}>
                    {currentUser?.name}
                  </span>
                  <ChevronDown className={`w-3.5 h-3.5 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`} />
                </button>

                {userMenuOpen && (
                  <div className={`spring-enter absolute right-0 mt-2 w-56 rounded-xl shadow-layer-3 py-2 z-50 glass-effect-strong ${theme === 'dark' ? 'border-gray-700/50' : 'border-gray-200/50'}`}>
                    <div className={`px-4 py-3 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-100'}`}>
                      <p className={`text-sm font-medium ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{currentUser?.name}</p>
                      <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>当前角色：{getRoleLabel(currentUser?.role)}</p>
                    </div>
                    <button
                      onClick={() => { onTabChange('relay'); setUserMenuOpen(false); }}
                      className={`w-full px-4 py-2.5 text-left text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'}`}
                    >
                      <GitBranch className="w-4 h-4 inline mr-2" />
                      <span>我的学术基因链</span>
                    </button>
                    <button className={`w-full px-4 py-2.5 text-left text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'}`}>
                      <Settings className="w-4 h-4 inline mr-2" />
                      <span>个人设置</span>
                    </button>
                    <button
                      onClick={() => { setRoleModalOpen(true); setUserMenuOpen(false); }}
                      className={`w-full px-4 py-2.5 text-left text-sm ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-700' : 'text-gray-700 hover:bg-gray-50'}`}
                    >
                      <RefreshCw className="w-4 h-4 inline mr-2" />
                      <span>切换角色</span>
                    </button>
                    <div className={`border-t mt-2 ${theme === 'dark' ? 'border-gray-700' : 'border-gray-100'}`} />
                    <button
                      onClick={handleLogout}
                      className={`w-full px-4 py-2.5 text-left text-sm ${theme === 'dark' ? 'text-red-400 hover:bg-gray-700' : 'text-red-500 hover:bg-gray-50'}`}
                    >
                      <LogOut className="w-4 h-4 inline mr-2" />
                      <span>退出登录</span>
                    </button>
                  </div>
                )}
              </div>

              {/* 移动端汉堡菜单 */}
              <button
                onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                className={`md:hidden p-2 rounded-lg ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-100'}`}
              >
                {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>
        </div>

        {/* ================================================================ */}
        {/*  移动端抽屉式导航 (Drawer Navigation)                              */}
        {/* ================================================================ */}
        {/* 遮罩层 */}
        <div
          className={`fixed inset-0 z-40 transition-opacity duration-300 md:hidden ${
            mobileMenuOpen ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'
          } ${theme === 'dark' ? 'bg-black/60' : 'bg-black/40'}`}
          onClick={() => setMobileMenuOpen(false)}
        />

        {/* 抽屉面板 */}
        <div
          className={`fixed top-0 right-0 h-full z-50 w-72 max-w-[85vw] transform transition-transform duration-300 ease-out md:hidden ${
            mobileMenuOpen ? 'translate-x-0' : 'translate-x-full'
          } ${theme === 'dark' ? 'bg-gray-900 border-l border-gray-700' : 'bg-white border-l border-gray-200'}`}
        >
          {/* 抽屉头部 */}
          <div className={`flex items-center justify-between px-4 py-3.5 border-b ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-center space-x-2">
              <div className={`w-8 h-8 rounded-lg flex items-center justify-center ${theme === 'dark' ? 'bg-primary-600' : 'bg-primary-500'}`}>
                <Sparkles className="w-4.5 h-4.5 text-white" />
              </div>
              <h1 className={`text-base font-bold ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>学术基因库</h1>
            </div>
            <button
              onClick={() => setMobileMenuOpen(false)}
              className={`p-2 rounded-lg ${theme === 'dark' ? 'text-gray-300 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-100'}`}
            >
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>

          {/* 积分 — 手机端抽屉内显示 */}
          {currentUser?.role === 'student' && (
            <div className="px-4 py-3 border-b">
              <div className={`flex items-center space-x-2 px-3 py-2.5 rounded-lg ${theme === 'dark' ? 'bg-yellow-600/20' : 'bg-yellow-50'}`}>
                <span className="text-yellow-500">🏆</span>
                <span className={`font-semibold ${theme === 'dark' ? 'text-yellow-400' : 'text-yellow-600'}`}>
                  {currentUser?.points || 0}
                </span>
                <span className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>积分</span>
              </div>
            </div>
          )}

          {/* 抽屉导航项 */}
          <div className="px-3 py-2 space-y-1 overflow-y-auto" style={{ maxHeight: 'calc(100vh - 200px)' }}>
            {/* 核心模块 */}
            <p className={`px-3 py-1.5 text-xs font-medium uppercase tracking-wide ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
              核心模块
            </p>
            {navGroups.core.map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { onTabChange(item.id); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all ${
                    isActive
                      ? `${theme === 'dark' ? 'bg-primary-600 text-white' : 'bg-primary-500 text-white'}`
                      : theme === 'dark' ? 'text-gray-300 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4.5 h-4.5" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}

            {/* 次要模块 */}
            <p className={`px-3 py-1.5 pt-3 text-xs font-medium uppercase tracking-wide ${theme === 'dark' ? 'text-gray-500' : 'text-gray-400'}`}>
              更多功能
            </p>
            {navGroups.secondary.concat(navGroups.alwaysOverflow || []).map((item) => {
              const Icon = item.icon;
              const isActive = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => { onTabChange(item.id); setMobileMenuOpen(false); }}
                  className={`w-full flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all ${
                    isActive
                      ? `${theme === 'dark' ? 'bg-primary-600 text-white' : 'bg-primary-500 text-white'}`
                      : theme === 'dark' ? 'text-gray-300 hover:bg-gray-800' : 'text-gray-600 hover:bg-gray-100'
                  }`}
                >
                  <Icon className="w-4.5 h-4.5" />
                  <span className="text-sm font-medium">{item.label}</span>
                </button>
              );
            })}
          </div>

          {/* 抽屉底部 — 用户操作 */}
          <div className={`absolute bottom-0 left-0 right-0 p-4 border-t ${theme === 'dark' ? 'border-gray-700' : 'border-gray-200'}`}>
            <div className="flex items-center space-x-3 mb-3">
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-semibold ${theme === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-200 text-gray-600'}`}>
                {currentUser?.name?.charAt(0) || '?'}
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-sm font-medium truncate ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>{currentUser?.name}</p>
                <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>{getRoleLabel(currentUser?.role)}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <button
                onClick={() => { setRoleModalOpen(true); setMobileMenuOpen(false); }}
                className={`flex-1 py-2 rounded-lg text-sm ${theme === 'dark' ? 'bg-gray-800 hover:bg-gray-700' : 'bg-gray-100 hover:bg-gray-200'}`}
              >
                切换角色
              </button>
              <button
                onClick={handleLogout}
                className={`flex-1 py-2 rounded-lg text-sm ${theme === 'dark' ? 'bg-red-900/40 text-red-400 hover:bg-red-900/60' : 'bg-red-50 text-red-600 hover:bg-red-100'}`}
              >
                退出登录
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* 角色切换弹窗 */}
      <RoleSwitchModal
        isOpen={roleModalOpen}
        onClose={() => setRoleModalOpen(false)}
        currentUser={currentUser}
        theme={theme}
        onRoleSwitch={handleRoleSwitch}
      />

      {/* 主内容区域 */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {children}
      </main>

      {/* Footer */}
      <footer className={`mt-auto py-6 border-t ${theme === 'dark' ? 'border-gray-800 bg-gray-900/85' : 'border-gray-200 bg-white/85'}`}>
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className={`text-sm ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            © 2026 校园学术基因库 - 传承智慧，接力未来
          </p>
        </div>
      </footer>
    </div>
  );
};