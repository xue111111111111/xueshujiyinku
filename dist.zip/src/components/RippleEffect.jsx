import { useState, useEffect, useCallback } from 'react';

/**
 * RippleEffect - 点击水波纹效果组件
 * 包裹按钮或其他可点击元素，点击时产生扩散水波纹
 */
export function RippleEffect({ children, className = '', color = 'rgba(255,255,255,0.35)' }) {
  const [ripples, setRipples] = useState([]);

  const handleClick = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const size = Math.max(rect.width, rect.height) * 2;

    const id = Date.now();
    setRipples(prev => [...prev, { id, x, y, size }]);

    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
    }, 600);
  }, []);

  return (
    <div
      className={`relative overflow-hidden ${className}`}
      onClick={handleClick}
    >
      {ripples.map(ripple => (
        <span
          key={ripple.id}
          className="absolute rounded-full pointer-events-none animate-ripple"
          style={{
            left: ripple.x - ripple.size / 2,
            top: ripple.y - ripple.size / 2,
            width: ripple.size,
            height: ripple.size,
            background: color,
          }}
        />
      ))}
      {children}
    </div>
  );
}

/**
 * useRipple - 返回水波纹handler和JSX，用于已有onClick的元素
 */
export function useRipple(color = 'rgba(255,255,255,0.35)') {
  const [ripples, setRipples] = useState([]);

  const createRipple = useCallback((e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const size = Math.max(rect.width, rect.height) * 2;

    const id = Date.now() + Math.random();
    setRipples(prev => [...prev, { id, x, y, size }]);

    setTimeout(() => {
      setRipples(prev => prev.filter(r => r.id !== id));
    }, 600);
  }, [color]);

  const RippleContainer = useCallback(({ children, className = '' }) => (
    <div className={`relative overflow-hidden ${className}`} onClick={createRipple}>
      {children}
    </div>
  ), [createRipple]);

  return { ripples, createRipple, RippleContainer };
}

export default RippleEffect;