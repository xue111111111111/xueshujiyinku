import { useEffect, useRef, useCallback, useMemo } from 'react';

const PARTICLE_COUNT = 60;
const PARALLAX_FACTOR = 0.03;
const ATTRACT_RADIUS = 120;

const THEME_COLORS = [
  'rgba(99, 102, 241, 0.6)',
  'rgba(139, 92, 246, 0.5)',
  'rgba(168, 85, 247, 0.4)',
  'rgba(6, 182, 212, 0.5)',
  'rgba(16, 185, 129, 0.4)',
];

export default function HeroParallax({ children, className = '', theme = 'light' }) {
  const canvasRef = useRef(null);
  const containerRef = useRef(null);
  const animRef = useRef(null);
  const particlesRef = useRef([]);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0 });
  const dimsRef = useRef({ w: 0, h: 0 });

  const initParticles = useCallback((w, h) => {
    return Array.from({ length: PARTICLE_COUNT }, (_, i) => {
      const depth = 0.3 + Math.random() * 0.7; // 0.3=far, 1=close
      return {
        x: Math.random() * w,
        y: Math.random() * h,
        baseX: 0,
        baseY: 0,
        radius: 1 + depth * 3,
        depth,
        color: THEME_COLORS[Math.floor(Math.random() * THEME_COLORS.length)],
        vx: (Math.random() - 0.5) * 0.3,
        vy: (Math.random() - 0.5) * 0.3,
        opacity: 0.2 + depth * 0.5,
      };
    });
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');

    const resize = () => {
      const rect = container.getBoundingClientRect();
      const w = rect.width;
      const h = rect.height || 400;
      dimsRef.current = { w, h };
      canvas.width = w * devicePixelRatio;
      canvas.height = h * devicePixelRatio;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.scale(devicePixelRatio, devicePixelRatio);

      // Re-init particles and store base positions
      particlesRef.current = initParticles(w, h);
      particlesRef.current.forEach(p => {
        p.baseX = p.x;
        p.baseY = p.y;
      });
    };

    resize();
    window.addEventListener('resize', resize);

    // Mouse tracking
    const handleMouseMove = (e) => {
      const rect = container.getBoundingClientRect();
      mouseRef.current.targetX = e.clientX - rect.left;
      mouseRef.current.targetY = e.clientY - rect.top;
    };

    const handleMouseLeave = () => {
      mouseRef.current.targetX = dimsRef.current.w / 2;
      mouseRef.current.targetY = dimsRef.current.h / 2;
    };

    container.addEventListener('mousemove', handleMouseMove);
    container.addEventListener('mouseleave', handleMouseLeave);

    // Init mouse position to center
    mouseRef.current.targetX = dimsRef.current.w / 2;
    mouseRef.current.targetY = dimsRef.current.h / 2;
    mouseRef.current.x = dimsRef.current.w / 2;
    mouseRef.current.y = dimsRef.current.h / 2;

    const animate = () => {
      const { w, h } = dimsRef.current;
      ctx.clearRect(0, 0, w, h);

      // Smooth mouse follow
      const mx = mouseRef.current.x + (mouseRef.current.targetX - mouseRef.current.x) * 0.08;
      const my = mouseRef.current.y + (mouseRef.current.targetY - mouseRef.current.y) * 0.08;
      mouseRef.current.x = mx;
      mouseRef.current.y = my;

      particlesRef.current.forEach(p => {
        // Slow drift
        p.baseX += p.vx;
        p.baseY += p.vy;

        // Wrap around edges
        if (p.baseX < -20) p.baseX = w + 20;
        if (p.baseX > w + 20) p.baseX = -20;
        if (p.baseY < -20) p.baseY = h + 20;
        if (p.baseY > h + 20) p.baseY = -20;

        // Parallax offset based on mouse position and depth
        const dx = mx - p.baseX;
        const dy = my - p.baseY;
        const parallaxX = dx * PARALLAX_FACTOR * p.depth;
        const parallaxY = dy * PARALLAX_FACTOR * p.depth;

        p.x = p.baseX + parallaxX;
        p.y = p.baseY + parallaxY;

        // Mouse attraction
        const dist = Math.sqrt((mx - p.x) ** 2 + (my - p.y) ** 2);
        if (dist < ATTRACT_RADIUS) {
          const force = (1 - dist / ATTRACT_RADIUS) * 0.6 * p.depth;
          p.x += (mx - p.x) * force;
          p.y += (my - p.y) * force;
        }

        // Draw particle
        const isDark = theme === 'dark';
        const baseAlpha = isDark ? p.opacity * 0.6 : p.opacity * 0.4;
        ctx.save();
        ctx.globalAlpha = baseAlpha;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
        ctx.restore();
      });

      // Draw connections between nearby particles
      ctx.strokeStyle = theme === 'dark'
        ? 'rgba(99, 102, 241, 0.06)'
        : 'rgba(99, 102, 241, 0.04)';
      ctx.lineWidth = 0.5;
      const particles = particlesRef.current;
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 80) {
            ctx.globalAlpha = (1 - dist / 80) * 0.3;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      animRef.current = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      window.removeEventListener('resize', resize);
      container.removeEventListener('mousemove', handleMouseMove);
      container.removeEventListener('mouseleave', handleMouseLeave);
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [initParticles, theme]);

  return (
    <div ref={containerRef} className={`relative overflow-hidden ${className}`}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none"
        style={{ zIndex: 0 }}
      />
      <div className="relative z-10">
        {children}
      </div>
    </div>
  );
}