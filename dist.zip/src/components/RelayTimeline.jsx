import { useState, useEffect, useRef } from 'react';
import { useApp } from '../context/AppContext';
import { getRelayProjects, getGeneChain, getApplications } from '../utils/storage';
import { useScrollAnimation } from '../hooks/useScrollAnimation';
import { GitBranch, Clock, Users, CheckCircle, ArrowRight, Sparkles } from 'lucide-react';

const statusConfig = {
  recruiting: { label: '待接力', color: '#3b82f6', icon: Users },
  in_progress: { label: '接力中', color: '#f59e0b', icon: Clock },
  completed: { label: '已传承', color: '#10b981', icon: CheckCircle },
};

export function RelayTimeline() {
  const { theme } = useApp();
  const [projects, setProjects] = useState([]);
  const [geneChain, setGeneChain] = useState([]);
  const [applications, setApplications] = useState([]);
  const timelineRef = useRef(null);
  const [activeFilter, setActiveFilter] = useState('all');
  const lineAnimRef = useRef(null);

  useEffect(() => {
    setProjects(getRelayProjects().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)));
    setGeneChain(getGeneChain());
    setApplications(getApplications());
  }, []);

  // 滚动连线逐步绘制
  useEffect(() => {
    const timeline = timelineRef.current;
    if (!timeline) return;

    const svgLine = timeline.querySelector('.timeline-line');
    if (!svgLine) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const totalHeight = timeline.scrollHeight;
        const visibleRatio = entries[0].intersectionRatio;
        if (svgLine) {
          svgLine.style.strokeDasharray = totalHeight;
          svgLine.style.strokeDashoffset = totalHeight * (1 - Math.min(visibleRatio * 1.2, 1));
        }
      },
      { threshold: Array.from({ length: 20 }, (_, i) => i / 20) }
    );

    observer.observe(timeline);
    return () => observer.disconnect();
  }, [projects]);

  const filteredProjects = activeFilter === 'all'
    ? projects
    : projects.filter(p => p.status === activeFilter);

  const getChainForProject = (projectId) => {
    return geneChain.filter(g =>
      g.fromProjectId === projectId || g.toProjectId === projectId
    );
  };

  return (
    <div className="space-y-6">
      {/* 标题 */}
      <div className={`rounded-xl p-6 ${
        theme === 'dark'
          ? 'bg-gradient-to-br from-purple-900/30 to-indigo-900/30 border border-gray-700'
          : 'bg-gradient-to-br from-purple-50 to-indigo-50 border border-purple-100'
      }`}>
        <h2 className={`text-xl font-bold flex items-center space-x-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
          <GitBranch className="w-6 h-6 text-purple-500" />
          <span>接力项目时间线</span>
        </h2>
        <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
          展示学术项目从发起到传承的完整历程
        </p>
      </div>

      {/* 筛选器 */}
      <div className="flex space-x-2">
        {[
          { key: 'all', label: '全部' },
          { key: 'recruiting', label: '待接力' },
          { key: 'in_progress', label: '接力中' },
          { key: 'completed', label: '已传承' }
        ].map(f => (
          <button
            key={f.key}
            onClick={() => setActiveFilter(f.key)}
            className={`btn-interactive px-4 py-1.5 rounded-full text-sm font-medium transition-all ${
              activeFilter === f.key
                ? theme === 'dark'
                  ? 'bg-indigo-600 text-white'
                  : 'bg-indigo-500 text-white shadow-md'
                : theme === 'dark'
                  ? 'bg-gray-800 text-gray-400 hover:text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* 时间线 */}
      <div ref={timelineRef} className="relative pl-10">
        {/* SVG 连线 */}
        <svg className="absolute left-[19px] top-0 h-full w-1" style={{ zIndex: 0 }}>
          <line
            className="timeline-line"
            x1="0" y1="0" x2="0" y2="100%"
            stroke={theme === 'dark' ? '#4b5563' : '#e5e7eb'}
            strokeWidth="3"
            strokeLinecap="round"
            style={{ transition: 'stroke-dashoffset 0.1s linear' }}
          />
        </svg>

        {/* 节点列表 */}
        <div className="space-y-0">
          {filteredProjects.map((project, index) => {
            const config = statusConfig[project.status] || statusConfig.recruiting;
            const chainLinks = getChainForProject(project.id);
            const projectApps = applications.filter(a => a.projectId === project.id);
            const approvedCount = projectApps.filter(a => a.status === 'approved').length;

            return (
              <TimelineNode
                key={project.id}
                project={project}
                config={config}
                index={index}
                theme={theme}
                chainLinks={chainLinks}
                applicantCount={projectApps.length}
                approvedCount={approvedCount}
              />
            );
          })}
        </div>
      </div>
    </div>
  );
}

function TimelineNode({ project, config, index, theme, chainLinks, applicantCount, approvedCount }) {
  const nodeRef = useRef(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const node = nodeRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          observer.unobserve(node);
        }
      },
      { threshold: 0.3, rootMargin: '0px 0px -40px 0px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, []);

  const IconComponent = config.icon;

  return (
    <div
      ref={nodeRef}
      className="relative pb-8"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateX(0)' : 'translateX(-20px)',
        transition: `all 0.5s cubic-bezier(0.16, 1, 0.3, 1) ${index * 100}ms`,
      }}
    >
      {/* 圆点指示器 */}
      <div
        className="absolute left-[-30px] w-5 h-5 rounded-full border-2 z-10 transition-transform duration-300 hover:scale-125"
        style={{
          top: 6,
          backgroundColor: config.color,
          borderColor: config.color,
          boxShadow: `0 0 12px ${config.color}40`
        }}
      />

      {/* 卡片内容 */}
      <div className={`rounded-xl p-5 transition-all duration-300 ${
        theme === 'dark'
          ? 'bg-gray-800 border border-gray-700 hover:border-gray-600'
          : 'bg-white border border-gray-100 shadow-sm hover:shadow-md'
      }`}>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center space-x-2 mb-2">
              <span
                className="px-2 py-0.5 rounded-full text-xs font-medium"
                style={{
                  backgroundColor: `${config.color}20`,
                  color: config.color,
                }}
              >
                {config.label}
              </span>
              <span className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
                {project.createdAt}
              </span>
            </div>

            <h3 className={`font-semibold text-lg mb-1 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              {project.title}
            </h3>
            <p className={`text-sm leading-relaxed ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {project.description}
            </p>

            {/* 标签 */}
            <div className="flex flex-wrap items-center space-x-2 mt-3">
              <span className={`inline-flex items-center space-x-1 px-2 py-0.5 rounded text-xs ${
                theme === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
              }`}>
                <Users className="w-3 h-3" />
                <span>{applicantCount} 人申请 · {approvedCount} 人通过</span>
              </span>
              {project.difficulty && (
                <span className={`px-2 py-0.5 rounded text-xs ${
                  theme === 'dark' ? 'bg-gray-700 text-gray-300' : 'bg-gray-100 text-gray-600'
                }`}>
                  难度: {project.difficulty}
                </span>
              )}
            </div>

            {/* 传承链 */}
            {chainLinks.length > 0 && (
              <div className="mt-3 pt-3 border-t border-gray-200 dark:border-gray-700">
                <div className="flex flex-wrap items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                  {chainLinks.map((link, li) => (
                    <div key={li} className="flex items-center space-x-1">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        theme === 'dark' ? 'bg-indigo-900/50 text-indigo-300' : 'bg-indigo-50 text-indigo-600'
                      }`}>
                        {link.relation}
                      </span>
                      {li < chainLinks.length - 1 && (
                        <ArrowRight className="w-3 h-3 text-gray-400" />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* 时间标记 */}
          <div className={`text-right ml-6 hidden sm:block ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
            <div className="text-xs mb-1">
              {new Date(project.createdAt).toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' })}
            </div>
            <div className="text-xs">
              {new Date(project.createdAt).getFullYear()}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default RelayTimeline;