import { useApp } from '../context/AppContext';
import CountUp from './CountUp';
import { BookOpen, GitBranch, Coins } from 'lucide-react';

/**
 * LiveStatsSnapshot - 实时学习快照动态卡片
 * 展示今日上传数、待接力项目数、积分变化
 */
export function LiveStatsSnapshot({ todayUploads, pendingRelays, points }) {
  const { theme } = useApp();

  const items = [
    { icon: BookOpen, label: '今日上传', value: todayUploads, suffix: '', color: '#6366f1', bg: 'bg-gradient-to-br from-indigo-500/10 to-blue-500/5' },
    { icon: GitBranch, label: '待接力', value: pendingRelays, suffix: '', color: '#8b5cf6', bg: 'bg-gradient-to-br from-purple-500/10 to-violet-500/5' },
    { icon: Coins, label: '积分变化', value: points, suffix: '', color: '#f59e0b', bg: 'bg-gradient-to-br from-amber-500/10 to-yellow-500/5' },
  ];

  return (
    <div className="grid grid-cols-3 gap-2">
      {items.map((item, i) => (
        <div
          key={item.label}
          className={`group relative rounded-lg px-3 py-2.5 cursor-default overflow-hidden transition-all duration-300 hover:-translate-y-0.5 hover:shadow-sm ${
            theme === 'dark' ? 'bg-gray-800/80 hover:bg-gray-800' : 'bg-white/90 hover:bg-white'
          }`}
          style={{
            borderLeft: `2px solid ${item.color}`,
          }}
        >
          <div className="flex items-center space-x-2">
            <item.icon className="w-4 h-4" style={{ color: item.color }} />
            <span className={`text-[11px] ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {item.label}
            </span>
          </div>
          <p className={`text-lg font-bold mt-0.5 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
            <CountUp end={item.value} duration={600} />
            {item.suffix}
          </p>
        </div>
      ))}
    </div>
  );
}

export default LiveStatsSnapshot;