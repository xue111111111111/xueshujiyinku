import { useState, useEffect, useRef, useCallback } from 'react';
import { useApp } from '../context/AppContext';
import { getAssets, getRelayProjects, getApplications, getExchanges } from '../utils/storage';
import {
  Award, Star, BookOpen, GraduationCap, GitBranch, ShoppingCart,
  MessageSquare, Users, TrendingUp, Zap, Shield, Crown, X
} from 'lucide-react';

// 徽章定义
const BADGE_DEFINITIONS = [
  { id: 'first_upload', name: '初次产出', icon: BookOpen, description: '上传第一个学习资料', color: '#6366f1', bg: 'bg-indigo-100', condition: (s) => s.totalAssets >= 1 },
  { id: 'scholar', name: '学术达人', icon: GraduationCap, description: '上传超过10个学习资料', color: '#8b5cf6', bg: 'bg-purple-100', condition: (s) => s.totalAssets >= 10 },
  { id: 'prolific', name: '高产作者', icon: Star, description: '上传超过30个学习资料', color: '#f59e0b', bg: 'bg-yellow-100', condition: (s) => s.totalAssets >= 30 },
  { id: 'relay_starter', name: '传承发起', icon: GitBranch, description: '发起第一个接力项目', color: '#10b981', bg: 'bg-green-100', condition: (s) => s.totalProjects >= 1 },
  { id: 'relay_master', name: '接力大师', icon: Award, description: '参与超过5个接力项目', color: '#06b6d4', bg: 'bg-cyan-100', condition: (s) => s.totalApplications >= 5 },
  { id: 'shopper', name: '积分达人', icon: ShoppingCart, description: '完成首次积分兑换', color: '#ef4444', bg: 'bg-red-100', condition: (s) => s.totalExchanges >= 1 },
  { id: 'trending', name: '人气之星', icon: TrendingUp, description: '资料被引用超过50次', color: '#f97316', bg: 'bg-orange-100', condition: (s) => s.totalCitations >= 50 },
  { id: 'mentor', name: '学术导师', icon: Users, description: '辅导超过3个接力申请', color: '#14b8a6', bg: 'bg-teal-100', condition: (s) => s.approvedApplications >= 3 },
  { id: 'power_user', name: '全能学者', icon: Crown, description: '达成5个以上徽章', color: '#eab308', bg: 'bg-amber-100', condition: () => false },
  { id: 'early_bird', name: '先登学府', icon: Zap, description: '系统上线首周活跃用户', color: '#3b82f6', bg: 'bg-blue-100', condition: () => true },
  { id: 'persistent', name: '持之以恒', icon: Shield, description: '连续7天上传资料', color: '#6b7280', bg: 'bg-gray-100', condition: () => false },
  { id: 'commentator', name: '评论达人', icon: MessageSquare, description: '发表超过10条学术评论', color: '#ec4899', bg: 'bg-pink-100', condition: () => false },
];

export function BadgeWall() {
  const { theme } = useApp();
  const [badges, setBadges] = useState([]);
  const [selectedBadge, setSelectedBadge] = useState(null);
  const [stats, setStats] = useState(null);
  const observerRef = useRef(null);

  // 计算用户统计
  useEffect(() => {
    const assets = getAssets();
    const relayProjects = getRelayProjects();
    const applications = getApplications();
    const exchanges = getExchanges();

    const s = {
      totalAssets: assets.length,
      totalProjects: relayProjects.length,
      totalApplications: applications.length,
      totalExchanges: exchanges.length,
      totalCitations: 82, // mock数据
      approvedApplications: applications.filter(a => a.status === 'approved').length,
    };
    setStats(s);

    const earned = BADGE_DEFINITIONS.filter(b => b.condition(s));
    const totalEarned = earned.length;

    // 如果达成5个以上徽章，自动解锁"全能学者"徽章
    const allBadges = BADGE_DEFINITIONS.map((b, i) => ({
      ...b,
      earned: b.id === 'power_user' ? totalEarned >= 5 : b.condition(s),
      earnedAt: b.condition(s) ? `2026-${String(1 + Math.floor(i / 2)).padStart(2, '0')}-${String(10 + i).padStart(2, '0')}` : null,
    }));

    setBadges(allBadges);
  }, []);

  // 交错入场动画
  useEffect(() => {
    if (!observerRef.current) return;
    const items = observerRef.current.querySelectorAll('.badge-item');
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry, i) => {
          if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0) scale(1)';
            observer.unobserve(entry.target);
          }
        });
      },
      { threshold: 0.15, rootMargin: '0px 0px -30px 0px' }
    );
    items.forEach(item => observer.observe(item));
    return () => observer.disconnect();
  }, [badges]);

  const earnedCount = badges.filter(b => b.earned).length;

  return (
    <div ref={observerRef} className="space-y-6">
      {/* 头部统计 */}
      <div className={`rounded-xl p-6 ${
        theme === 'dark'
          ? 'bg-gradient-to-br from-indigo-900/40 to-purple-900/40 border border-gray-700'
          : 'bg-gradient-to-br from-indigo-50 to-purple-50 border border-indigo-100'
      }`}>
        <div className="flex items-center justify-between">
          <div>
            <h2 className={`text-xl font-bold flex items-center space-x-2 ${theme === 'dark' ? 'text-white' : 'text-gray-900'}`}>
              <Award className="w-6 h-6 text-amber-500" />
              <span>学术成就徽章墙</span>
            </h2>
            <p className={`text-sm mt-1 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              您的学术旅程里程碑
            </p>
          </div>
          <div className="text-center">
            <p className={`text-3xl font-bold ${theme === 'dark' ? 'text-amber-400' : 'text-amber-600'} transition-transform`}>
              {earnedCount}
            </p>
            <p className={`text-xs ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              / {badges.length} 徽章
            </p>
          </div>
        </div>
        {/* 渐变发光进度条 */}
        <div className="mt-4">
          <div className={`h-2 rounded-full overflow-hidden ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-200'}`}>
            <div
              className="h-full rounded-full progress-glow transition-all duration-1000 ease-out"
              style={{ width: `${(earnedCount / badges.length) * 100}%` }}
            />
          </div>
        </div>
      </div>

      {/* 瀑布流徽章网格 */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {badges.map((badge, index) => (
          <div
            key={badge.id}
            className="badge-item"
            style={{
              opacity: 0,
              transform: 'translateY(20px) scale(0.9)',
              transition: `all 0.4s cubic-bezier(0.16, 1, 0.3, 1) ${index * 60}ms`,
            }}
          >
            <div
              onClick={() => badge.earned && setSelectedBadge(badge)}
              className={`relative rounded-xl p-4 text-center transition-all duration-300 ${
                badge.earned
                  ? theme === 'dark'
                    ? 'bg-gray-800 border border-gray-700 hover:border-indigo-500/50 hover:shadow-lg hover:shadow-indigo-500/10 cursor-pointer badge-earned-dark'
                    : `bg-white border border-gray-100 hover:shadow-xl hover:-translate-y-1 cursor-pointer badge-earned-light`
                  : theme === 'dark'
                    ? 'bg-gray-800/50 border border-gray-700/50 opacity-50 grayscale'
                    : 'bg-gray-50 border border-gray-100 opacity-50 grayscale'
              }`}
            >
              {/* 徽章图标 */}
              <div className={`w-14 h-14 mx-auto rounded-full flex items-center justify-center mb-2 transition-all duration-300 ${
                badge.earned ? 'group-hover:scale-110 badge-glow' : ''
              }`}
                style={{
                  background: badge.earned
                    ? `linear-gradient(135deg, ${badge.color}20, ${badge.color}40)`
                    : '#e5e7eb',
                  boxShadow: badge.earned ? `0 0 15px ${badge.color}40, 0 0 30px ${badge.color}20` : 'none'
                }}
              >
                <badge.icon
                  className="w-7 h-7 transition-all duration-300"
                  style={{ 
                    color: badge.earned ? badge.color : '#9ca3af',
                    filter: badge.earned ? 'none' : 'grayscale(100%)'
                  }}
                />
              </div>

              <p className={`text-xs font-medium ${badge.earned ? (theme === 'dark' ? 'text-gray-200' : 'text-gray-800') : 'text-gray-400'}`}>
                {badge.name}
              </p>
              <p className="text-[10px] text-gray-400 mt-0.5 line-clamp-2">
                {badge.earned ? badge.description : '尚未解锁'}
              </p>

              {/* 已获取标记 */}
              {badge.earned && (
                <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-green-500 flex items-center justify-center badge-completed">
                  <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                  </svg>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* 徽章详情弹窗 */}
      {selectedBadge && (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4" onClick={() => setSelectedBadge(null)}>
          <div
            className={`spring-enter w-full max-w-sm rounded-2xl p-6 text-center ${
              theme === 'dark' ? 'bg-gray-800 text-white' : 'bg-white text-gray-900'
            }`}
            onClick={e => e.stopPropagation()}
          >
            <button onClick={() => setSelectedBadge(null)} className="absolute top-4 right-4 p-1 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700">
              <X className="w-5 h-5" />
            </button>

            <div className="w-20 h-20 mx-auto rounded-full flex items-center justify-center mb-4"
              style={{ background: `linear-gradient(135deg, ${selectedBadge.color}20, ${selectedBadge.color}40)` }}
            >
              <selectedBadge.icon className="w-10 h-10" style={{ color: selectedBadge.color }} />
            </div>

            <h3 className="text-xl font-bold mb-1">{selectedBadge.name}</h3>
            <p className={`text-sm mb-4 ${theme === 'dark' ? 'text-gray-400' : 'text-gray-500'}`}>
              {selectedBadge.description}
            </p>

            <div className={`rounded-lg p-3 ${theme === 'dark' ? 'bg-gray-700' : 'bg-gray-50'}`}>
              <p className="text-xs text-gray-500">获得时间</p>
              <p className="font-medium">{selectedBadge.earnedAt}</p>
            </div>

            <button
              onClick={() => setSelectedBadge(null)}
              className="btn-interactive mt-4 w-full py-2 rounded-lg bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium"
            >
              知道了
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default BadgeWall;