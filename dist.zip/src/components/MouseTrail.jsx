import { useEffect, useRef, useCallback, useState } from 'react';

// 主题粒子图标集
const SYMBOLS = ['◇', '◆', '◈', '⬡', '⬢', '▸', '▪', '▴', '✧', '∘'];

export const MouseTrail = () => {
  const trailRef = useRef([]);
  const mouseRef = useRef({ x: -100, y: -100 });
  const frameRef = useRef(null);
  const [trails, setTrails] = useState([]);
  const [isTouch, setIsTouch] = useState(false);
  const overInteractiveRef = useRef(false);

  // 检测移动端
  useEffect(() => {
    setIsTouch('ontouchstart' in window || navigator.maxTouchPoints > 0);
  }, []);

  const onMouseMove = useCallback((e) => {
    mouseRef.current = { x: e.clientX, y: e.clientY };
  }, []);

  const onMouseEnterInteractive = useCallback(() => { overInteractiveRef.current = true; }, []);
  const onMouseLeaveInteractive = useCallback(() => { overInteractiveRef.current = false; }, []);

  useEffect(() => {
    if (isTouch) return;

    // 监听可交互元素的 hover
    const interactives = document.querySelectorAll('button, a, .card-enhanced, [role="button"], input, select, textarea');
    interactives.forEach((el) => {
      el.addEventListener('mouseenter', onMouseEnterInteractive);
      el.addEventListener('mouseleave', onMouseLeaveInteractive);
    });

    const ob = new MutationObserver(() => {
      const newEls = document.querySelectorAll('button, a, .card-enhanced, [role="button"], input, select, textarea');
      newEls.forEach((el) => {
        el.removeEventListener('mouseenter', onMouseEnterInteractive);
        el.removeEventListener('mouseleave', onMouseLeaveInteractive);
        el.addEventListener('mouseenter', onMouseEnterInteractive);
        el.addEventListener('mouseleave', onMouseLeaveInteractive);
      });
    });
    ob.observe(document.body, { childList: true, subtree: true });

    return () => {
      interactives.forEach((el) => {
        el.removeEventListener('mouseenter', onMouseEnterInteractive);
        el.removeEventListener('mouseleave', onMouseLeaveInteractive);
      });
      ob.disconnect();
    };
  }, [isTouch, onMouseEnterInteractive, onMouseLeaveInteractive]);

  // RAF 驱动的粒子更新
  useEffect(() => {
    if (isTouch) return;
    window.addEventListener('mousemove', onMouseMove, { passive: true });

    let lastTime = performance.now();
    let lastX = mouseRef.current.x;
    let lastY = mouseRef.current.y;

    const animate = (now) => {
      const dt = Math.min(now - lastTime, 50);
      const { x, y } = mouseRef.current;

      // 计算移动速度
      const dx = x - lastX;
      const dy = y - lastY;
      const speed = Math.sqrt(dx * dx + dy * dy);
      lastX = x;
      lastY = y;

      // 按速度生成粒子（速度快时多生成）
      const count = Math.min(Math.floor(speed / 15), 4);
      if (count > 0 && x > 0 && y > 0) {
        const newParticles = [];
        for (let i = 0; i < count; i++) {
          newParticles.push({
            id: Date.now() + Math.random(),
            x: x + (Math.random() - 0.5) * 8,
            y: y + (Math.random() - 0.5) * 8,
            symbol: SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
            opacity: 0.5 + Math.random() * 0.3,
            size: 8 + Math.random() * 6,
            createdAt: now,
            // 交互元素上时聚拢高亮
            clustered: overInteractiveRef.current,
          });
        }
        trailRef.current = [...trailRef.current.slice(-40), ...newParticles];
      }

      // 清理过期粒子 + 更新位置
      const alive = trailRef.current
        .map((p) => {
          const age = now - p.createdAt;
          const fade = 1 - age / 800;
          const drift = p.clustered ? 0.5 : 1.5;
          return {
            ...p,
            opacity: Math.max(0, p.opacity * fade),
            x: p.x + (Math.random() - 0.5) * drift,
            y: p.y + (Math.random() - 0.5) * drift,
            scale: fade * 1.2,
          };
        })
        .filter((p) => p.opacity > 0.02);

      trailRef.current = alive;
      setTrails(alive);
      lastTime = now;
      frameRef.current = requestAnimationFrame(animate);
    };

    frameRef.current = requestAnimationFrame(animate);
    return () => {
      window.removeEventListener('mousemove', onMouseMove);
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
    };
  }, [isTouch, onMouseMove]);

  if (isTouch) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9998]" style={{ overflow: 'hidden' }}>
      {trails.map((p) => (
        <span
          key={p.id}
          className="absolute select-none"
          style={{
            left: p.x,
            top: p.y,
            opacity: p.opacity,
            transform: `translate(-50%, -50%) scale(${p.scale || 1})`,
            fontSize: `${p.size}px`,
            color: p.clustered ? '#818cf8' : '#94a3b8',
            transition: p.clustered ? 'color 0.15s ease' : 'none',
          }}
        >
          {p.symbol}
        </span>
      ))}
    </div>
  );
};