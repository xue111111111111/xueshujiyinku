import { useRef, useState, useCallback } from 'react';

/**
 * TiltCard - 3D倾斜视差卡片容器
 * 通过 perspective + rotateX/rotateY 实现鼠标跟随倾斜
 */
export function TiltCard({ children, className = '', maxTilt = 5, scale = 1.02, glare = false }) {
  const cardRef = useRef(null);
  const [style, setStyle] = useState({
    transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg)',
    boxShadow: '',
  });
  const [glareStyle, setGlareStyle] = useState({ opacity: 0 });

  const handleMouseMove = useCallback((e) => {
    const card = cardRef.current;
    if (!card) return;

    const rect = card.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;

    const rotateY = ((x - centerX) / centerX) * maxTilt;
    const rotateX = -((y - centerY) / centerY) * maxTilt;

    const shadowX = ((x - centerX) / centerX) * 10;
    const shadowY = ((y - centerY) / centerY) * 10;

    setStyle({
      transform: `perspective(1000px) rotateX(${rotateX}deg) rotateY(${rotateY}deg) scale3d(${scale}, ${scale}, ${scale})`,
      boxShadow: `${shadowX}px ${shadowY}px 30px rgba(0,0,0,0.15), 0 0 15px rgba(99,102,241,0.15)`,
    });

    if (glare) {
      const glareX = (x / rect.width) * 100;
      const glareY = (y / rect.height) * 100;
      setGlareStyle({
        opacity: 0.06,
        background: `radial-gradient(circle at ${glareX}% ${glareY}%, rgba(255,255,255,0.8) 0%, transparent 60%)`,
      });
    }
  }, [maxTilt, scale, glare]);

  const handleMouseLeave = useCallback(() => {
    setStyle({
      transform: 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale3d(1,1,1)',
      boxShadow: '',
      transition: 'all 0.4s cubic-bezier(0.16, 1, 0.3, 1)',
    });
    if (glare) {
      setGlareStyle({ opacity: 0, transition: 'opacity 0.3s' });
    }
    // Remove transition after it completes
    setTimeout(() => {
      setStyle(prev => ({ ...prev, transition: 'none' }));
    }, 400);
  }, [glare]);

  return (
    <div
      ref={cardRef}
      className={`relative overflow-hidden transition-[box-shadow] duration-200 ${className}`}
      style={{
        ...style,
        willChange: 'transform',
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      {glare && (
        <div
          className="absolute inset-0 pointer-events-none z-10"
          style={glareStyle}
        />
      )}
      {children}
    </div>
  );
}

export default TiltCard;