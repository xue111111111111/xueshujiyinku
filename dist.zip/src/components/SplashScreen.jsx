import { useEffect, useRef, useState, useCallback } from 'react';
import gsap from 'gsap';

const PARTICLE_COUNT = 200;
const DNA_HELIX_RADIUS = 70;
const DNA_HELIX_HEIGHT = 350;
const DNA_ROTATION_SPEED = 0.02;

const COLORS = [
  '#6366f1', '#8b5cf6', '#a855f7', '#d946ef',
  '#06b6d4', '#10b981', '#3b82f6', '#f59e0b'
];

export default function SplashScreen({ onComplete }) {
  const canvasRef = useRef(null);
  const textRef = useRef(null);
  const progressRef = useRef(null);
  const containerRef = useRef(null);
  const [progress, setProgress] = useState(0);
  const [displayText, setDisplayText] = useState('');
  const [showText, setShowText] = useState(false);
  const [animReady, setAnimReady] = useState(false);
  const [isExiting, setIsExiting] = useState(false);
  const [textGlow, setTextGlow] = useState(false);
  const animRef = useRef(null);
  const particlesRef = useRef([]);
  const timeRef = useRef(0);
  const rippleParticlesRef = useRef([]);

  const slogan = '探索知识的基因密码';
  const subtitle = '校园学术基因库';

  // DNA粒子系统 - 升级版本
  const initParticles = useCallback((width, height) => {
    const particles = [];
    const centerX = width / 2;
    const centerY = height / 2;

    for (let i = 0; i < PARTICLE_COUNT; i++) {
      const t = i / PARTICLE_COUNT;
      const angle = t * Math.PI * 10; // 5 full rotations for helix
      const y = (t - 0.5) * DNA_HELIX_HEIGHT;

      // Strand 1
      const x1 = centerX + Math.cos(angle) * DNA_HELIX_RADIUS;
      const z1 = Math.sin(angle) * DNA_HELIX_RADIUS;

      // Strand 2 (offset by PI)
      const x2 = centerX + Math.cos(angle + Math.PI) * DNA_HELIX_RADIUS;
      const z2 = Math.sin(angle + Math.PI) * DNA_HELIX_RADIUS;

      // 蓝紫渐变配色
      const colorIndex = Math.floor(t * COLORS.length);
      const color = COLORS[colorIndex % COLORS.length];
      const size = 1 + Math.random() * 4;

      particles.push({
        x1, y1: centerY + y, z1, x2, y2: centerY + y, z2,
        baseX1: x1, baseY1: centerY + y, baseZ1: z1,
        baseX2: x2, baseY2: centerY + y, baseZ2: z2,
        color, size, t, angleOffset: angle,
        glow: 0.3 + Math.random() * 0.7,
        twinkle: Math.random() * Math.PI * 2,
        wobbleOffset: Math.random() * 0.3,
        connections: []
      });
    }

    // Build rung connections
    for (let i = 0; i < particles.length - 1; i++) {
      particles[i].connections.push(i + 1);
    }

    return particles;
  }, []);

  // 绘制DNA粒子 - 升级版本
  const drawDNA = useCallback((ctx, particles, width, height, time, progress) => {
    ctx.clearRect(0, 0, width, height);

    // 根据进度调整旋转速度
    const speedMultiplier = 1 + progress * 0.02;
    const rotAngle = time * DNA_ROTATION_SPEED * speedMultiplier;

    // Update particle positions with rotation and wobble
    particles.forEach((p) => {
      const wobble = Math.sin(time * 2 + p.t * 5) * p.wobbleOffset * 10;
      const newAngle = p.angleOffset + rotAngle;
      p.x1 = width / 2 + Math.cos(newAngle) * (DNA_HELIX_RADIUS + wobble);
      p.z1 = Math.sin(newAngle) * (DNA_HELIX_RADIUS + wobble);
      p.x2 = width / 2 + Math.cos(newAngle + Math.PI) * (DNA_HELIX_RADIUS - wobble);
      p.z2 = Math.sin(newAngle + Math.PI) * (DNA_HELIX_RADIUS - wobble);
    });

    // Sort particles by z (back to front)
    const sorted = [...particles].sort((a, b) => a.z1 - b.z1);

    // Draw rungs (connections) with glow
    sorted.forEach((p, idx) => {
      if (idx < sorted.length - 1) {
        const opacity = 0.2 + 0.2 * Math.sin(time * 3 + p.t * 10);
        const gradient = ctx.createLinearGradient(p.x1, p.y1, sorted[idx + 1].x1, sorted[idx + 1].y1);
        gradient.addColorStop(0, `rgba(99, 102, 241, ${opacity})`);
        gradient.addColorStop(0.5, `rgba(139, 92, 246, ${opacity})`);
        gradient.addColorStop(1, `rgba(168, 85, 247, ${opacity})`);
        ctx.strokeStyle = gradient;
        ctx.lineWidth = 0.8;
        ctx.shadowColor = '#8b5cf6';
        ctx.shadowBlur = 4;
        ctx.beginPath();
        ctx.moveTo(p.x1, p.y1);
        ctx.lineTo(sorted[idx + 1].x1, sorted[idx + 1].y1);
        ctx.stroke();

        const gradient2 = ctx.createLinearGradient(p.x2, p.y2, sorted[idx + 1].x2, sorted[idx + 1].y2);
        gradient2.addColorStop(0, `rgba(168, 85, 247, ${opacity})`);
        gradient2.addColorStop(0.5, `rgba(139, 92, 246, ${opacity})`);
        gradient2.addColorStop(1, `rgba(99, 102, 241, ${opacity})`);
        ctx.strokeStyle = gradient2;
        ctx.beginPath();
        ctx.moveTo(p.x2, p.y2);
        ctx.lineTo(sorted[idx + 1].x2, sorted[idx + 1].y2);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    });

    // Draw cross-rungs with pulse
    sorted.forEach((p) => {
      const alpha = 0.1 + 0.1 * Math.sin(time * 4 + p.t * 15);
      ctx.strokeStyle = `rgba(139, 92, 246, ${alpha})`;
      ctx.lineWidth = 0.5;
      ctx.beginPath();
      ctx.moveTo(p.x1, p.y1);
      ctx.lineTo(p.x2, p.y2);
      ctx.stroke();
    });

    // Draw particles with collision glow effect
    sorted.forEach((p) => {
      const twinkle = 0.5 + 0.5 * Math.sin(time * 5 + p.twinkle);
      const alpha = p.glow * twinkle;
      const scale = 1 + 0.3 * Math.sin(time * 4 + p.t * 15);

      // Strand 1 - Main particle with glow
      ctx.save();
      ctx.globalAlpha = alpha;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 12 * p.glow * twinkle;
      ctx.beginPath();
      ctx.arc(p.x1, p.y1, p.size * scale, 0, Math.PI * 2);
      const gradient = ctx.createRadialGradient(p.x1, p.y1, 0, p.x1, p.y1, p.size * scale);
      gradient.addColorStop(0, 'rgba(255, 255, 255, 0.8)');
      gradient.addColorStop(0.3, p.color);
      gradient.addColorStop(1, `${p.color}88`);
      ctx.fillStyle = gradient;
      ctx.fill();
      ctx.restore();

      // Strand 2 - Slightly smaller
      ctx.save();
      ctx.globalAlpha = alpha * 0.7;
      ctx.shadowColor = p.color;
      ctx.shadowBlur = 8 * p.glow * twinkle;
      ctx.beginPath();
      ctx.arc(p.x2, p.y2, p.size * scale * 0.7, 0, Math.PI * 2);
      const gradient2 = ctx.createRadialGradient(p.x2, p.y2, 0, p.x2, p.y2, p.size * scale * 0.7);
      gradient2.addColorStop(0, 'rgba(255, 255, 255, 0.6)');
      gradient2.addColorStop(0.3, p.color);
      gradient2.addColorStop(1, `${p.color}66`);
      ctx.fillStyle = gradient2;
      ctx.fill();
      ctx.restore();
    });
  }, []);

  // 绘制波纹粒子
  const drawRippleParticles = useCallback((ctx, particles, width, height) => {
    particles.forEach((p) => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.1; // gravity
      p.life -= 0.015;
      p.size *= 1.02;

      if (p.life > 0) {
        ctx.save();
        ctx.globalAlpha = p.life;
        ctx.shadowColor = p.color;
        ctx.shadowBlur = p.size;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.fill();
        ctx.restore();
      }
    });

    rippleParticlesRef.current = particles.filter(p => p.life > 0);
  }, []);

  // 动画循环
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    let w = window.innerWidth;
    let h = window.innerHeight;

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * devicePixelRatio;
      canvas.height = h * devicePixelRatio;
      canvas.style.width = w + 'px';
      canvas.style.height = h + 'px';
      ctx.scale(devicePixelRatio, devicePixelRatio);
      particlesRef.current = initParticles(w, h);
    };

    resize();
    window.addEventListener('resize', resize);

    const animate = () => {
      timeRef.current += 1;
      drawDNA(ctx, particlesRef.current, w, h, timeRef.current * 0.02, progress);
      
      // 绘制波纹粒子
      if (rippleParticlesRef.current.length > 0) {
        drawRippleParticles(ctx, rippleParticlesRef.current, w, h);
      }
      
      animRef.current = requestAnimationFrame(animate);
    };
    animate();

    return () => {
      window.removeEventListener('resize', resize);
      if (animRef.current) cancelAnimationFrame(animRef.current);
    };
  }, [initParticles, drawDNA, drawRippleParticles, progress]);

  // 进度条 + 文字动画
  useEffect(() => {
    const tl = gsap.timeline();

    // 进度条动画 0-100% 在4.3s内
    const progressObj = { value: 0 };
    gsap.to(progressObj, {
      value: 100,
      duration: 4.3,
      ease: 'power2.inOut',
      onUpdate: () => setProgress(Math.round(progressObj.value)),
      onComplete: () => {
        setProgress(100);
      }
    });

    // 延迟显示文字打字节（0.8s后开始，每字120ms）
    setTimeout(() => {
      setShowText(true);
      let charIndex = 0;
      const interval = setInterval(() => {
        charIndex++;
        if (charIndex <= slogan.length) {
          setDisplayText(slogan.substring(0, charIndex));
        } else {
          clearInterval(interval);
          // 打字完成后触发发光效果
          setTimeout(() => setTextGlow(true), 300);
        }
      }, 120);
    }, 800);

    // 5s后动画就绪，显示点击进入按钮
    setTimeout(() => {
      setAnimReady(true);
    }, 5000);
  }, [onComplete]);

  // 创建爆发粒子
  const createExplosion = (x, y) => {
    const explosionParticles = [];
    for (let i = 0; i < 100; i++) {
      const angle = (i / 100) * Math.PI * 2;
      const speed = 2 + Math.random() * 6;
      explosionParticles.push({
        x,
        y,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        size: 2 + Math.random() * 4,
        life: 1,
        color: COLORS[Math.floor(Math.random() * COLORS.length)]
      });
    }
    rippleParticlesRef.current.push(...explosionParticles);
  };

  const handleEnter = () => {
    setIsExiting(true);
    
    // 创建全屏爆发效果
    const centerX = window.innerWidth / 2;
    const centerY = window.innerHeight / 2;
    createExplosion(centerX, centerY);
    
    // 在多个位置创建爆发
    setTimeout(() => createExplosion(centerX - 100, centerY - 50), 100);
    setTimeout(() => createExplosion(centerX + 100, centerY + 50), 200);
    setTimeout(() => createExplosion(centerX - 50, centerY + 100), 150);

    gsap.to(containerRef.current, {
      opacity: 0,
      duration: 0.8,
      ease: 'power2.in',
      onComplete: () => onComplete?.()
    });
  };

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-gradient-to-b from-gray-950 via-gray-900 to-gray-950 overflow-hidden"
    >
      {/* 背景渐变装饰 */}
      <div className="absolute inset-0 bg-gradient-radial from-indigo-900/20 via-transparent to-purple-900/20" />
      
      <canvas
        ref={canvasRef}
        className="absolute inset-0"
      />

      {/* 文字区域 */}
      <div className="relative z-10 text-center px-4">
        {showText && (
          <div ref={textRef}>
            <h1 
              className={`text-3xl sm:text-4xl md:text-5xl font-bold mb-3 transition-all duration-500 ${
                textGlow ? 'text-glow-active' : ''
              }`}
              style={{ 
                minHeight: '3rem',
                background: 'linear-gradient(90deg, #60a5fa, #a78bfa, #f0abfc, #60a5fa)',
                backgroundSize: '300% 100%',
                backgroundClip: 'text',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: textGlow ? 'transparent' : 'rgba(255,255,255,0.9)',
                animation: textGlow ? 'gradientText 3s ease infinite, textGlowPulse 2s ease-in-out infinite' : 'none',
                textShadow: textGlow ? '0 0 30px rgba(167, 139, 250, 0.5), 0 0 60px rgba(96, 165, 250, 0.3)' : 'none'
              }}
            >
              {displayText}
              <span className="animate-pulse text-purple-400">|</span>
            </h1>
            <p className="text-sm sm:text-base text-gray-400 opacity-0"
              style={{ animation: 'fadeIn 0.6s ease-out 1.5s forwards' }}
            >
              {subtitle}
            </p>
          </div>
        )}

        {/* 进度条 */}
        <div className="relative z-10 mt-8 w-48 sm:w-64 mx-auto">
          <div className="h-1.5 bg-gray-800/50 rounded-full overflow-hidden">
            <div
              ref={progressRef}
              className="h-full rounded-full transition-all duration-300 ease-out relative"
              style={{
                width: `${progress}%`,
                background: 'linear-gradient(90deg, #6366f1, #8b5cf6, #a855f7)',
                boxShadow: '0 0 15px rgba(139, 92, 246, 0.5)'
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer" />
            </div>
          </div>
          <p className="text-xs text-gray-600 mt-2 text-center">
            {animReady ? '准备就绪' : `${progress}%`}
          </p>
        </div>

        {/* 点击进入按钮 */}
        {animReady && (
          <div className="mt-8">
            <button
              onClick={handleEnter}
              disabled={isExiting}
              className="group relative px-10 py-4 text-lg font-medium text-white rounded-full overflow-hidden transition-all duration-500 hover:scale-105 active:scale-95 button-ripple"
              style={{
                background: 'linear-gradient(135deg, #6366f1, #8b5cf6, #a855f7)',
                boxShadow: '0 0 40px rgba(99, 102, 241, 0.5), inset 0 0 30px rgba(255, 255, 255, 0.1)',
                animation: 'buttonGlow 3s ease-in-out infinite'
              }}
            >
              <span className="relative z-10 flex items-center space-x-2">
                <span>进入系统</span>
                <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7l5 5m0 0l-5 5m5-5H6" />
                </svg>
              </span>
              <div className="absolute inset-0 bg-white opacity-0 group-hover:opacity-10 transition-opacity" />
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent -translate-x-full group-hover:translate-x-full transition-transform duration-700" />
            </button>
            <p className="text-xs text-gray-600 mt-3 text-center animate-pulse">
              点击进入校园学术基因库
            </p>
          </div>
        )}
      </div>

      {/* 底部品牌 */}
      <div className="absolute bottom-6 text-center">
        <p className="text-xs text-gray-700 tracking-widest uppercase opacity-0"
          style={{ animation: 'fadeIn 0.5s ease-out 2s forwards' }}
        >
          Campus Academic Gene Bank
        </p>
      </div>
    </div>
  );
}