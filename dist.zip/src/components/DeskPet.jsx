import { useState, useEffect, useRef, useCallback } from 'react';
import { useSpring, animated } from '@react-spring/web';
import { useDrag } from '@use-gesture/react';
import { X, Minimize2, Maximize2 } from 'lucide-react';
import { usePet } from '../context/PetContext';
import { useApp } from '../context/AppContext';

// 趣味提示语库
const messages = [
  '今日学习产出 +1 ✨',
  '知识正在传递中... 🔬',
  '基因链又延长了！🧬',
  '学术能力 +1% 🧠',
  '下一个里程碑在等你 🏆',
  '继续加油，学霸！💪',
  '学海无涯，基因无限 🌊',
  '灵感来了！记录一下 ✍️',
  '知识基因正在复制... 🧪',
  '今日值得喝彩 🎉',
];

const actions = ['bounce', 'wave', 'spin', 'nod'];

export const DeskPet = () => {
  const { petVisible, petMinimized, setPetMinimized, setPetVisible, petCelebrate, petMessage, petPosition, savePosition } = usePet();
  const { currentUser, theme } = useApp();
  const [currentAction, setCurrentAction] = useState('idle');
  const [bubbleMsg, setBubbleMsg] = useState('');
  const [showBubble, setShowBubble] = useState(false);
  const bubbleTimer = useRef(null);
  const idleTimer = useRef(null);
  const petSize = 64; // w-16 = 64px

  // 默认位置：右下角
  const defaultPos = useRef(() => ({
    x: window.innerWidth - petSize - 20,
    y: window.innerHeight - petSize - 20,
  }));

  // 弹簧动画，从保存位置或默认位置初始化
  const initPos = petPosition || defaultPos.current();
  const [{ x, y }, api] = useSpring(() => ({
    x: initPos.x, y: initPos.y,
    config: { tension: 300, friction: 20 },
  }));

  // 窗口 resize 时重新计算边界
  useEffect(() => {
    const handleResize = () => {
      const vw = window.innerWidth; const vh = window.innerHeight;
      api.start((current) => {
        const cx = Math.max(0, Math.min(current.x, vw - petSize));
        const cy = Math.max(0, Math.min(current.y, vh - petSize));
        return { x: cx, y: cy, config: { tension: 300, friction: 20 } };
      });
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [api, petSize]);

  // 拖拽
  const bind = useDrag(
    ({ movement: [mx, my], active, down }) => {
      const startX = initPos.x + mx;
      const startY = initPos.y + my;
      api.start({ x: startX, y: startY, immediate: active, config: { tension: 280, friction: 22 } });
      if (!active) {
        // 松手：边界限制 + 边缘吸附
        const vw = window.innerWidth;
        const vh = window.innerHeight;
        let clampX = Math.max(0, Math.min(startX, vw - petSize));
        let clampY = Math.max(0, Math.min(startY, vh - petSize));

        // 边缘吸附（8px 阈值）
        const snapEdge = 8;
        if (clampX < snapEdge) clampX = 0;
        else if (clampX > vw - petSize - snapEdge) clampX = vw - petSize;
        if (clampY < snapEdge) clampY = 0;
        else if (clampY > vh - petSize - snapEdge) clampY = vh - petSize;

        api.start({ x: clampX, y: clampY, config: { tension: 200, friction: 20 } });
        // 保存位置
        savePosition({ x: clampX, y: clampY });
      }
    },
    { from: () => [x.get(), y.get()], filterTaps: true, preventDefault: true }
  );

  // 显示气泡消息
  const showBubbleMsg = useCallback((msg, duration = 3000) => {
    if (bubbleTimer.current) clearTimeout(bubbleTimer.current);
    setBubbleMsg(msg);
    setShowBubble(true);
    bubbleTimer.current = setTimeout(() => setShowBubble(false), duration);
  }, []);

  // 随机空闲动作
  useEffect(() => {
    if (!petVisible) return;
    const cycle = () => {
      idleTimer.current = setTimeout(() => {
        const rand = actions[Math.floor(Math.random() * actions.length)];
        setCurrentAction(rand);
        setTimeout(() => setCurrentAction('idle'), 1500);
        cycle();
      }, 4000 + Math.random() * 4000);
    };
    cycle();
    return () => { if (idleTimer.current) clearTimeout(idleTimer.current); };
  }, [petVisible]);

  // 庆祝动画
  useEffect(() => {
    if (petCelebrate) {
      setCurrentAction('bounce');
      const texts = { upload: '上传成功！知识库 +1 🎉', submit: '申请已提交！🤝', redeem: '兑换成功！🎁' };
      showBubbleMsg(texts[petCelebrate] || '🎉');
      setTimeout(() => setCurrentAction('idle'), 2500);
    }
  }, [petCelebrate, showBubbleMsg]);

  // 外部消息
  useEffect(() => {
    if (petMessage) showBubbleMsg(petMessage);
  }, [petMessage, showBubbleMsg]);

  // 点击事件
  const handleClick = () => {
    if (petMinimized) { setPetMinimized(false); return; }
    const rand = actions[Math.floor(Math.random() * actions.length)];
    setCurrentAction(rand);
    const msg = messages[Math.floor(Math.random() * messages.length)];
    showBubbleMsg(msg);
    setTimeout(() => setCurrentAction('idle'), 1500);
  };

  // 最小化
  const handleMinimize = (e) => { e.stopPropagation(); setPetMinimized(!petMinimized); };
  const handleClose = (e) => { e.stopPropagation(); setPetVisible(false); };

  if (!petVisible) return null;

  const isDark = theme === 'dark';
  const primary = isDark ? '#818cf8' : '#6366f1';
  const secondary = isDark ? '#a78bfa' : '#8b5cf6';

  // 最小化状态：小图标
  if (petMinimized) {
    return (
      <animated.div
        style={{ left: x, top: y, position: 'fixed', zIndex: 30, touchAction: 'none' }}
        {...bind()}
      >
        <div
          onClick={handleClick}
          className="w-10 h-10 rounded-full flex items-center justify-center cursor-pointer shadow-lg transition-all hover:scale-110 hover:shadow-xl"
          style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
          title="点击展开学术精灵"
        >
          <span className="text-lg">🧬</span>
        </div>
      </animated.div>
    );
  }

  return (
    <animated.div
      style={{ left: x, top: y, position: 'fixed', zIndex: 30, touchAction: 'none' }}
      {...bind()}
    >
      <div className="relative select-none">
        {/* 对话气泡 */}
        {showBubble && (
          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-3 whitespace-nowrap">
            <div
              className="px-3 py-2 rounded-xl text-xs font-medium shadow-md animate-pet-bubble"
              style={{
                background: isDark ? 'rgba(30,41,59,0.95)' : 'rgba(255,255,255,0.95)',
                color: isDark ? '#e2e8f0' : '#1e293b',
                border: `1px solid ${isDark ? 'rgba(148,163,184,0.3)' : 'rgba(203,213,225,0.5)'}`,
              }}
            >
              {bubbleMsg}
              {/* 气泡尾巴 */}
              <div
                className="absolute left-1/2 -translate-x-1/2 -bottom-1.5 w-3 h-3 rotate-45"
                style={{
                  background: isDark ? 'rgba(30,41,59,0.95)' : 'rgba(255,255,255,0.95)',
                  borderRight: `1px solid ${isDark ? 'rgba(148,163,184,0.3)' : 'rgba(203,213,225,0.5)'}`,
                  borderBottom: `1px solid ${isDark ? 'rgba(148,163,184,0.3)' : 'rgba(203,213,225,0.5)'}`,
                }}
              />
            </div>
          </div>
        )}

        {/* 桌宠主体 */}
        <div
          onClick={handleClick}
          className={`w-16 h-16 rounded-2xl flex items-center justify-center cursor-pointer shadow-lg transition-shadow duration-300 hover:shadow-xl relative group ${currentAction}`}
          style={{ background: `linear-gradient(135deg, ${primary}, ${secondary})` }}
        >
          {/* DNA 双螺旋 SVG 精灵 */}
          <svg viewBox="0 0 48 48" className="w-10 h-10" fill="none">
            {/* 身体 — 试管/培养皿 */}
            <ellipse cx="24" cy="32" rx="14" ry="8" fill={isDark ? '#475569' : '#e2e8f0'} opacity="0.5" />
            {/* DNA 左链 */}
            <path
              d="M18 8 Q24 16 18 24 Q24 32 18 40"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
              className={currentAction === 'bounce' ? 'animate-pet-strand-l' : ''}
            />
            {/* DNA 右链 */}
            <path
              d="M30 8 Q24 16 30 24 Q24 32 30 40"
              stroke="white"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
              opacity="0.9"
              className={currentAction === 'bounce' ? 'animate-pet-strand-r' : ''}
            />
            {/* 碱基对 — 横桥 */}
            <line x1="19" y1="14" x2="29" y2="14" stroke="white" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
            <line x1="21" y1="20" x2="27" y2="20" stroke="white" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
            <line x1="21" y1="26" x2="27" y2="26" stroke="white" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
            <line x1="19" y1="32" x2="29" y2="32" stroke="white" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
            <line x1="18" y1="37" x2="30" y2="37" stroke="white" strokeWidth="1.5" opacity="0.6" strokeLinecap="round" />
            {/* 头顶光圈 */}
            <circle cx="24" cy="6" r="3" fill="white" opacity="0.8" />
            <circle cx="23" cy="5" r="1" fill={isDark ? '#6366f1' : '#4f46e5'} />
            <circle cx="25" cy="5" r="1" fill={isDark ? '#6366f1' : '#4f46e5'} />
          </svg>

          {/* 控制按钮 — hover 显示 */}
          <div className="absolute -top-1 -right-1 flex gap-0.5 opacity-0 group-hover:opacity-100 transition-opacity duration-200">
            <button
              onClick={handleMinimize}
              className="w-4.5 h-4.5 rounded-full bg-white/90 text-gray-500 flex items-center justify-center hover:bg-white shadow-sm"
              title="最小化"
            >
              <Minimize2 size={10} />
            </button>
            <button
              onClick={handleClose}
              className="w-4.5 h-4.5 rounded-full bg-white/90 text-gray-500 flex items-center justify-center hover:bg-red-100 hover:text-red-500 shadow-sm"
              title="关闭"
            >
              <X size={10} />
            </button>
          </div>
        </div>
      </div>

      <style>{`
        .bounce { animation: petBounce 0.4s ease-in-out; }
        .wave { animation: petWave 0.6s ease-in-out; }
        .spin { animation: petSpin 0.5s ease-in-out; }
        .nod { animation: petNod 0.5s ease-in-out; }

        @keyframes petBounce {
          0%, 100% { transform: translateY(0); }
          30% { transform: translateY(-12px) scale(1.05); }
          50% { transform: translateY(0) scale(0.95); }
          70% { transform: translateY(-6px); }
        }
        @keyframes petWave {
          0%, 100% { transform: rotate(0deg); }
          25% { transform: rotate(-8deg); }
          50% { transform: rotate(8deg); }
          75% { transform: rotate(-4deg); }
        }
        @keyframes petSpin {
          0% { transform: rotate(0deg) scale(1); }
          50% { transform: rotate(180deg) scale(1.1); }
          100% { transform: rotate(360deg) scale(1); }
        }
        @keyframes petNod {
          0%, 100% { transform: translateY(0) rotate(0deg); }
          30% { transform: translateY(-3px) rotate(-5deg); }
          60% { transform: translateY(-3px) rotate(5deg); }
        }
        @keyframes animate-pet-bubble {
          0% { opacity: 0; transform: translateY(8px) scale(0.9); }
          20% { opacity: 1; transform: translateY(0) scale(1); }
          80% { opacity: 1; }
          100% { opacity: 0; }
        }
        @keyframes animate-pet-strand-l {
          0%, 100% { d: path('M18 8 Q24 16 18 24 Q24 32 18 40'); }
          50% { d: path('M16 8 Q22 18 16 26 Q22 34 16 40'); }
        }
        @keyframes animate-pet-strand-r {
          0%, 100% { d: path('M30 8 Q24 16 30 24 Q24 32 30 40'); }
          50% { d: path('M32 8 Q26 18 32 26 Q26 34 32 40'); }
        }
        .animate-pet-bubble { animation: animate-pet-bubble 3s ease-in-out forwards; }
        .animate-pet-strand-l { animation: animate-pet-strand-l 0.4s ease-in-out infinite; }
        .animate-pet-strand-r { animation: animate-pet-strand-r 0.4s ease-in-out infinite; }
      `}</style>
    </animated.div>
  );
};