import { useEffect, useRef } from 'react';

/**
 * 全局动态粒子背景 - Canvas实现
 * DNA片段、书本、代码符号、原子结构等主题粒子
 * 蓝紫渐变主色调，呼吸缩放，粒子连线
 * z-index: -1，不遮挡任何内容
 */

const PARTICLE_COUNT = 65;
const CONNECTION_DIST = 150;
const COLORS = [
  'rgba(99, 102, 241,',   // indigo
  'rgba(139, 92, 246,',   // violet
  'rgba(168, 85, 247,',   // purple
  'rgba(79, 70, 229,',    // indigo-dark
  'rgba(124, 58, 237,',   // violet-dark
  'rgba(59, 130, 246,',   // blue
];

// 粒子形状绘制函数
const drawDNA = (ctx, x, y, size, color, alpha) => {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  // 双螺旋片段
  ctx.beginPath();
  ctx.arc(x, y - size * 0.3, size * 0.5, 0, Math.PI);
  ctx.stroke();
  ctx.beginPath();
  ctx.arc(x, y + size * 0.3, size * 0.5, Math.PI, Math.PI * 2);
  ctx.stroke();
  // 连接线
  ctx.beginPath();
  ctx.moveTo(x - size * 0.5, y - size * 0.3);
  ctx.lineTo(x - size * 0.5, y + size * 0.3);
  ctx.moveTo(x + size * 0.5, y - size * 0.3);
  ctx.lineTo(x + size * 0.5, y + size * 0.3);
  ctx.stroke();
  ctx.restore();
};

const drawBook = (ctx, x, y, size, color, alpha) => {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  // 书本轮廓
  ctx.beginPath();
  ctx.rect(x - size * 0.4, y - size * 0.35, size * 0.8, size * 0.7);
  ctx.stroke();
  // 书脊
  ctx.beginPath();
  ctx.moveTo(x, y - size * 0.35);
  ctx.lineTo(x, y + size * 0.35);
  ctx.stroke();
  // 页面线
  ctx.beginPath();
  ctx.moveTo(x + size * 0.1, y - size * 0.15);
  ctx.lineTo(x + size * 0.3, y - size * 0.15);
  ctx.moveTo(x + size * 0.1, y);
  ctx.lineTo(x + size * 0.3, y);
  ctx.moveTo(x + size * 0.1, y + size * 0.15);
  ctx.lineTo(x + size * 0.3, y + size * 0.15);
  ctx.stroke();
  ctx.restore();
};

const drawCode = (ctx, x, y, size, color, alpha) => {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 1;
  // </> 符号
  ctx.beginPath();
  ctx.moveTo(x - size * 0.5, y);
  ctx.lineTo(x - size * 0.2, y - size * 0.3);
  ctx.moveTo(x - size * 0.5, y);
  ctx.lineTo(x - size * 0.2, y + size * 0.3);
  ctx.moveTo(x + size * 0.5, y);
  ctx.lineTo(x + size * 0.2, y - size * 0.3);
  ctx.moveTo(x + size * 0.5, y);
  ctx.lineTo(x + size * 0.2, y + size * 0.3);
  ctx.stroke();
  // 斜杠
  ctx.beginPath();
  ctx.moveTo(x + size * 0.05, y - size * 0.35);
  ctx.lineTo(x - size * 0.05, y + size * 0.35);
  ctx.stroke();
  ctx.restore();
};

const drawAtom = (ctx, x, y, size, color, alpha) => {
  ctx.save();
  ctx.globalAlpha = alpha;
  ctx.strokeStyle = color;
  ctx.lineWidth = 0.8;
  // 原子核
  ctx.beginPath();
  ctx.arc(x, y, size * 0.12, 0, Math.PI * 2);
  ctx.fillStyle = color;
  ctx.fill();
  // 轨道
  ctx.beginPath();
  ctx.ellipse(x, y, size * 0.5, size * 0.2, 0, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(x, y, size * 0.5, size * 0.2, Math.PI / 3, 0, Math.PI * 2);
  ctx.stroke();
  ctx.beginPath();
  ctx.ellipse(x, y, size * 0.5, size * 0.2, -Math.PI / 3, 0, Math.PI * 2);
  ctx.stroke();
  ctx.restore();
};

const SHAPES = [drawDNA, drawBook, drawCode, drawAtom];

export const BackgroundParticles = () => {
  const canvasRef = useRef(null);
  const frameRef = useRef(null);
  const particlesRef = useRef([]);
  const isTouchRef = useRef(false);

  useEffect(() => {
    isTouchRef.current = 'ontouchstart' in window || navigator.maxTouchPoints > 0;
  }, []);

  useEffect(() => {
    if (isTouchRef.current) return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    // 适配画布尺寸
    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    const w = () => canvas.width;
    const h = () => canvas.height;

    // 初始化粒子
    const particles = Array.from({ length: PARTICLE_COUNT }, (_, i) => ({
      id: i,
      x: Math.random() * w(),
      y: Math.random() * h(),
      vx: (Math.random() - 0.5) * 0.4,
      vy: (Math.random() - 0.5) * 0.4,
      size: 4 + Math.random() * 8,
      baseOpacity: 0.08 + Math.random() * 0.04,
      colorIndex: Math.floor(Math.random() * COLORS.length),
      shapeIndex: Math.floor(Math.random() * SHAPES.length),
      // 呼吸缩放参数
      breathPhase: Math.random() * Math.PI * 2,
      breathSpeed: (2 * Math.PI) / (3000 + Math.random() * 2000), // 3-5秒周期
      scale: 1,
    }));
    particlesRef.current = particles;

    let lastTime = performance.now();

    const animate = (now) => {
      const dt = Math.min(now - lastTime, 50);
      lastTime = now;

      ctx.clearRect(0, 0, w(), h());

      // 更新粒子位置与呼吸缩放
      particles.forEach(p => {
        p.x += p.vx * (dt / 16);
        p.y += p.vy * (dt / 16);

        // 边界反弹
        if (p.x < 0 || p.x > w()) { p.vx *= -1; p.x = Math.max(0, Math.min(w(), p.x)); }
        if (p.y < 0 || p.y > h()) { p.vy *= -1; p.y = Math.max(0, Math.min(h(), p.y)); }

        // 呼吸缩放：0.8 → 1.2 → 0.8
        p.breathPhase += p.breathSpeed * dt;
        p.scale = 1 + 0.2 * Math.sin(p.breathPhase);
      });

      // 绘制连线
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < CONNECTION_DIST) {
            const lineAlpha = (1 - dist / CONNECTION_DIST) * 0.06;
            ctx.save();
            ctx.globalAlpha = lineAlpha;
            ctx.strokeStyle = COLORS[particles[i].colorIndex] + '1)';
            ctx.lineWidth = 0.5;
            ctx.beginPath();
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
            ctx.restore();
          }
        }
      }

      // 绘制粒子
      particles.forEach(p => {
        const color = COLORS[p.colorIndex] + '1)';
        const alpha = p.baseOpacity;
        const drawSize = p.size * p.scale;
        SHAPES[p.shapeIndex](ctx, p.x, p.y, drawSize, color, alpha);
      });

      frameRef.current = requestAnimationFrame(animate);
    };

    frameRef.current = requestAnimationFrame(animate);

    return () => {
      if (frameRef.current) cancelAnimationFrame(frameRef.current);
      window.removeEventListener('resize', resize);
    };
  }, []);

  if (isTouchRef.current) return null;

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
};
