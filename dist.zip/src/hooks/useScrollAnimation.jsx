import { useEffect, useRef, useState, useCallback } from 'react';

/**
 * useScrollAnimation - 滚动触发入场动画 Hook
 *
 * @param {Object} options
 * @param {number} options.threshold - 触发阈值 (0-1), 默认 0.15
 * @param {string} options.animation - 动画类型: 'fadeUp' | 'fadeIn' | 'fadeLeft' | 'fadeRight' | 'scaleIn'
 * @param {number} options.delay - 延迟时间(ms), 用于交错动画
 * @param {boolean} options.once - 是否只触发一次, 默认 true
 * @param {string} options.rootMargin - rootMargin, 默认 '0px 0px -50px 0px'
 */
export function useScrollAnimation(options = {}) {
  const {
    threshold = 0.15,
    animation = 'fadeUp',
    delay = 0,
    once = true,
    rootMargin = '0px 0px -50px 0px'
  } = options;

  const ref = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          // 延迟触发，支持交错动画
          if (delay > 0) {
            setTimeout(() => setIsVisible(true), delay);
          } else {
            setIsVisible(true);
          }
          if (once) {
            observer.unobserve(node);
          }
        } else if (!once) {
          setIsVisible(false);
        }
      },
      { threshold, rootMargin }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [threshold, delay, once, rootMargin]);

  const animStyles = {
    fadeUp: {
      transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
      opacity: isVisible ? 1 : 0,
    },
    fadeIn: {
      opacity: isVisible ? 1 : 0,
    },
    fadeLeft: {
      transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
      opacity: isVisible ? 1 : 0,
    },
    fadeRight: {
      transform: isVisible ? 'translateX(0)' : 'translateX(30px)',
      opacity: isVisible ? 1 : 0,
    },
    scaleIn: {
      transform: isVisible ? 'scale(1)' : 'scale(0.9)',
      opacity: isVisible ? 1 : 0,
    },
  };

  const transition = `all 0.6s cubic-bezier(0.16, 1, 0.3, 1) ${delay}ms`;

  return {
    ref,
    style: {
      ...animStyles[animation],
      transition,
    },
    isVisible,
  };
}

/**
 * AnimatedSection - 带滚动动画的容器组件
 */
export function AnimatedSection({
  children,
  animation = 'fadeUp',
  delay = 0,
  threshold = 0.15,
  className = '',
  as: Tag = 'div',
  ...props
}) {
  const { ref, style } = useScrollAnimation({ animation, delay, threshold });

  return (
    <Tag ref={ref} className={className} style={style} {...props}>
      {children}
    </Tag>
  );
}

/**
 * AnimatedList - 带序列交错动画的列表容器
 */
export function AnimatedList({
  children,
  animation = 'fadeUp',
  baseDelay = 80,
  threshold = 0.1,
  className = '',
}) {
  const containerRef = useRef(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const node = containerRef.current;
    if (!node) return;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(node);
        }
      },
      { threshold, rootMargin: '0px 0px -30px 0px' }
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [threshold]);

  return (
    <div ref={containerRef} className={className}>
      {Array.isArray(children)
        ? children.map((child, index) => (
            <div
              key={index}
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                transition: `all 0.5s cubic-bezier(0.16, 1, 0.3, 1) ${index * baseDelay}ms`,
              }}
            >
              {child}
            </div>
          ))
        : children}
    </div>
  );
}

export default useScrollAnimation;