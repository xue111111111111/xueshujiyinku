import { useState, useEffect, useCallback, useRef } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { PetProvider, usePet } from './context/PetContext';
import { Layout } from './components/Layout';
import { Assets } from './components/Assets';
import { Relay } from './components/Relay';
import { Shop } from './components/Shop';
import { SearchPage } from './components/Search';
import { Stats } from './components/Stats';
import { MyCourses } from './components/MyCourses';
import { Cases } from './components/Cases';
import { Approval } from './components/Approval';
import { UserManage } from './components/UserManage';
import { PointConfig } from './components/PointConfig';
import { System } from './components/System';
import { AIAssistant } from './components/AIAssistant';
import MergeRequests from './components/MergeRequests';
import Profile from './components/Profile';
import SplashScreen from './components/SplashScreen';
import GeneChain from './components/GeneChain';
import BadgeWall from './components/BadgeWall';
import RelayTimeline from './components/RelayTimeline';
import { RouteAnimator } from './components/RouteAnimator';
import { DeskPet } from './components/DeskPet';
import { MouseTrail } from './components/MouseTrail';
import { ClickRipple } from './components/ClickRipple';
import { BackgroundParticles } from './components/BackgroundParticles';

const EasterEggs = () => {
  const [clickBurst, setClickBurst] = useState([]);
  const clickCount = useRef(0);
  const clickTimer = useRef(null);
  const bottomNotified = useRef(false);
  const { showMessage } = usePet();

  // --- 连击5次触发粒子爆发 ---
  const handleGlobalClick = useCallback((e) => {
    // 空白区域点击
    const tag = e.target.tagName.toLowerCase();
    const isInteractive = ['button', 'a', 'input', 'select', 'textarea'].some(t => t === tag)
      || e.target.closest('button, a, [role="button"], input, select, textarea');
    if (isInteractive) return;

    if (clickTimer.current) clearTimeout(clickTimer.current);
    clickCount.current += 1;

    clickTimer.current = setTimeout(() => { clickCount.current = 0; }, 1500);

    if (clickCount.current >= 5) {
      clickCount.current = 0;
      // 生成爆发粒子
      const burst = Array.from({ length: 30 }, (_, i) => ({
        id: Date.now() + i,
        x: e.clientX + (Math.random() - 0.5) * 200,
        y: e.clientY + (Math.random() - 0.5) * 200,
      }));
      setClickBurst(burst);
      showMessage('知识粒子大爆发！✨');
      setTimeout(() => setClickBurst([]), 1500);
    }
  }, [showMessage]);

  // --- 滚动到底触发鼓励 ---
  useEffect(() => {
    const handleScroll = () => {
      const { scrollHeight, scrollTop, clientHeight } = document.documentElement;
      if (scrollHeight - scrollTop - clientHeight < 50 && !bottomNotified.current) {
        bottomNotified.current = true;
        showMessage('已经到底啦！你是最棒的 🚀');
        setTimeout(() => { bottomNotified.current = false; }, 5000);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [showMessage]);

  useEffect(() => {
    window.addEventListener('click', handleGlobalClick);
    return () => window.removeEventListener('click', handleGlobalClick);
  }, [handleGlobalClick]);

  if (clickBurst.length === 0) return null;

  return (
    <div className="pointer-events-none fixed inset-0 z-[9998]" style={{ overflow: 'hidden' }}>
      {clickBurst.map((p) => (
        <span
          key={p.id}
          className="absolute select-none animate-burst-particle"
          style={{
            left: p.x,
            top: p.y,
            fontSize: `${10 + Math.random() * 12}px`,
          }}
        >
          {['✨', '🧬', '💡', '🔬', '⭐', '📚', '🎓', '💎'][Math.floor(Math.random() * 8)]}
        </span>
      ))}
      <style>{`
        @keyframes burst-particle {
          0% { opacity: 1; transform: translate(0, 0) scale(1); }
          100% { opacity: 0; transform: translate(${Math.random() > 0.5 ? '' : '-'}${30 + Math.random() * 70}px, ${Math.random() > 0.5 ? '' : '-'}${30 + Math.random() * 70}px) scale(0.3); }
        }
        .animate-burst-particle { animation: burst-particle 1.2s ease-out forwards; }
      `}</style>
    </div>
  );
};

const AppContent = () => {
  const { currentUser } = useApp();
  const [activeTab, setActiveTab] = useState('assets');
  const [splashDone, setSplashDone] = useState(false);
  
  useEffect(() => {
    const relayDraft = localStorage.getItem('relayDraft');
    if (relayDraft) {
      setActiveTab('relay');
    }
  }, []);

  const handleSplashComplete = useCallback(() => {
    setSplashDone(true);
  }, []);
  
  const renderContent = () => {
    switch (activeTab) {
      case 'assets':
        return <Assets />;
      case 'relay':
        return <Relay />;
      case 'shop':
        return <Shop />;
      case 'search':
        return <SearchPage />;
      case 'stats':
        return <Stats />;
      case 'mergerequests':
        return <MergeRequests />;
      case 'genechain':
        return <GeneChain />;
      case 'badges':
        return <BadgeWall />;
      case 'relaytimeline':
        return <RelayTimeline />;
      case 'profile':
        return <Profile />;
      case 'mycourses':
        return <MyCourses />;
      case 'homework':
        return <div className="text-center py-12">作业管理功能开发中...</div>;
      case 'cases':
        return <Cases />;
      case 'approval':
        return <Approval />;
      case 'usermanage':
        return <UserManage />;
      case 'contentaudit':
        return <div className="text-center py-12">内容审核功能开发中...</div>;
      case 'pointconfig':
        return <PointConfig />;
      case 'system':
        return <System />;
      default:
        return <Assets />;
    }
  };

  return (
    <>
      {!splashDone && <SplashScreen onComplete={handleSplashComplete} />}
      <div style={{ visibility: splashDone ? 'visible' : 'hidden' }}>
        {/* 全局装饰层 */}
        <BackgroundParticles />
        <MouseTrail />
        <ClickRipple />
        <EasterEggs />
        <DeskPet />

        <Layout activeTab={activeTab} onTabChange={setActiveTab}>
          <RouteAnimator activeTab={activeTab}>
            {renderContent()}
          </RouteAnimator>
          <AIAssistant />
        </Layout>
      </div>
    </>
  );
};

function App() {
  return (
    <AppProvider>
      <PetProvider>
        <AppContent />
      </PetProvider>
    </AppProvider>
  );
}

export default App;