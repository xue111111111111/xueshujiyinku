import { createContext, useContext, useState, useEffect, useCallback } from 'react';

const PetContext = createContext();

const STORAGE_KEY_VISIBLE = 'pet_visible';
const STORAGE_KEY_MINIMIZED = 'pet_minimized';
const STORAGE_KEY_POSITION = 'pet_position';

export const PetProvider = ({ children }) => {
  const [petVisible, setPetVisibleState] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY_VISIBLE);
    return saved !== null ? saved === 'true' : true;
  });
  const [petMinimized, setPetMinimizedState] = useState(() => {
    const saved = localStorage.getItem(STORAGE_KEY_MINIMIZED);
    return saved !== null ? saved === 'true' : false;
  });
  const [petCelebrate, setPetCelebrate] = useState(null); // 'upload' | 'submit' | 'redeem' | null
  const [petMessage, setPetMessage] = useState('');
  const [petPosition, setPetPosition] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY_POSITION);
      return saved ? JSON.parse(saved) : null; // { x, y } 或 null（默认右下角）
    } catch { return null; }
  });

  // 监听 localStorage 变化（跨标签页同步）
  useEffect(() => {
    const handleStorage = (e) => {
      if (e.key === STORAGE_KEY_VISIBLE) setPetVisibleState(e.newValue === 'true');
      if (e.key === STORAGE_KEY_MINIMIZED) setPetMinimizedState(e.newValue === 'true');
      if (e.key === STORAGE_KEY_POSITION) {
        try { setPetPosition(e.newValue ? JSON.parse(e.newValue) : null); } catch {}
      }
    };
    window.addEventListener('storage', handleStorage);
    return () => window.removeEventListener('storage', handleStorage);
  }, []);

  const setPetVisible = useCallback((val) => {
    setPetVisibleState(val);
    localStorage.setItem(STORAGE_KEY_VISIBLE, String(val));
  }, []);

  const setPetMinimized = useCallback((val) => {
    setPetMinimizedState(val);
    localStorage.setItem(STORAGE_KEY_MINIMIZED, String(val));
  }, []);

  const togglePet = useCallback(() => {
    setPetVisibleState((prev) => {
      const next = !prev;
      localStorage.setItem(STORAGE_KEY_VISIBLE, String(next));
      return next;
    });
  }, []);

  const triggerCelebrate = useCallback((type) => {
    setPetCelebrate(type);
    setTimeout(() => setPetCelebrate(null), 2500);
  }, []);

  const showMessage = useCallback((msg) => {
    setPetMessage(msg);
    setTimeout(() => setPetMessage(''), 3000);
  }, []);

  const savePosition = useCallback((pos) => {
    setPetPosition(pos);
    localStorage.setItem(STORAGE_KEY_POSITION, JSON.stringify(pos));
  }, []);

  return (
    <PetContext.Provider value={{
      petVisible,
      setPetVisible,
      petMinimized,
      setPetMinimized,
      togglePet,
      petCelebrate,
      triggerCelebrate,
      petMessage,
      showMessage,
      petPosition,
      savePosition,
    }}>
      {children}
    </PetContext.Provider>
  );
};

export const usePet = () => {
  const ctx = useContext(PetContext);
  if (!ctx) throw new Error('usePet must be used within PetProvider');
  return ctx;
};